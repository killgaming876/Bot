// Server-side source of truth for product prices.
//
// SECURITY NOTE: the create-payment endpoint must NEVER trust a price sent
// from the browser. A person could edit the request and claim a $500
// product costs $1. This file mirrors just the fields the backend needs
// (id, name, price) to recompute the order total itself from the product
// ids the client sends.
//
// In production, point this at the same database/CMS that powers
// src/data/products.js on the frontend, so the two can never drift.

export const serverProducts = {
  'creator-productivity-starter-pack': { name: 'Creator Productivity Starter Pack', price: 19 },
  'ultimate-business-launch-kit': { name: 'Ultimate Business Launch Kit', price: 39 },
  'ai-productivity-toolkit': { name: 'AI Productivity Toolkit', price: 24 },
  'premium-website-ui-pack': { name: 'Premium Website UI Pack', price: 49 },
  'digital-marketing-blueprint': { name: 'Digital Marketing Blueprint', price: 29 },
  'freelancer-client-kit': { name: 'Freelancer Client Kit', price: 22 },
  'social-growth-templates': { name: 'Social Media Growth Templates', price: 27 },
  'business-finance-dashboard': { name: 'Business Finance Dashboard', price: 34 },
};

export function getServerProduct(id) {
  return serverProducts[id] || null;
}

export function priceCartItems(items) {
  let total = 0;
  const priced = [];
  for (const item of items) {
    const product = getServerProduct(item.id);
    if (!product) {
      throw new Error(`Unknown product id: ${item.id}`);
    }
    const quantity = Math.max(1, Math.min(10, Number(item.quantity) || 1));
    const lineTotal = product.price * quantity;
    total += lineTotal;
    priced.push({ id: item.id, name: product.name, price: product.price, quantity, lineTotal });
  }
  return { items: priced, total: Math.round(total * 100) / 100 };
}
