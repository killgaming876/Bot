// DEVELOPMENT-ONLY in-memory order store.
//
// This exists so the payment flow can be exercised end-to-end (create →
// status → webhook → success) without a real database attached yet.
//
// IMPORTANT FOR PRODUCTION:
// Vercel serverless functions do not share memory across invocations or
// regions, and this Map will be wiped on every cold start / redeploy.
// Before accepting real payments, replace this file's functions with calls
// to a real database (Postgres, PlanetScale, Supabase, DynamoDB, etc.) that
// several serverless function instances can all read and write safely.
// Keep the same function signatures (getOrder, createOrder, updateOrder,
// listOrdersByEmail) and nothing else in the API layer needs to change.

const orders = globalThis.__KAERUS_ORDERS__ || new Map();
globalThis.__KAERUS_ORDERS__ = orders;

export function createOrder(order) {
  orders.set(order.orderId, order);
  return order;
}

export function getOrder(orderId) {
  return orders.get(orderId) || null;
}

export function updateOrder(orderId, patch) {
  const existing = orders.get(orderId);
  if (!existing) return null;
  const updated = { ...existing, ...patch, updatedAt: new Date().toISOString() };
  orders.set(orderId, updated);
  return updated;
}

export function listOrdersByEmail(email) {
  return Array.from(orders.values()).filter((o) => o.customerEmail === email);
}
