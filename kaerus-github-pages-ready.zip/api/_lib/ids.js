import { randomUUID } from 'crypto';

export function generateOrderId() {
  const stamp = Date.now().toString(36).toUpperCase();
  const rand = randomUUID().split('-')[0].toUpperCase();
  return `KAE-${stamp}-${rand}`;
}

export function generateSessionToken() {
  return randomUUID();
}
