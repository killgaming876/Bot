// POST /api/payment/webhook
// The ONLY route in this app allowed to mark a real order as SUCCESS or
// FAILED. It only acts on requests whose signature verifies against the
// configured provider's webhook secret. If no provider is configured (test
// mode), verification always fails closed and this route can do nothing.
//
// Configure this exact URL in your payment provider's dashboard once you
// go live: https://yourdomain.com/api/payment/webhook

import { getOrder, updateOrder } from '../_lib/orderStore.js';
import { verifyProviderWebhook } from './_lib/provider.js';

export const config = {
  api: {
    bodyParser: false, // signature verification needs the raw body
  },
};

async function readRawBody(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  return Buffer.concat(chunks).toString('utf8');
}

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Method not allowed.' });
  }

  const rawBody = await readRawBody(req);
  const event = await verifyProviderWebhook({ headers: req.headers, rawBody });

  if (!event) {
    // Signature invalid, or no real provider configured. Never trust this
    // request. Respond generically — do not leak why verification failed.
    return res.status(400).json({ error: 'Invalid webhook signature.' });
  }

  const order = getOrder(event.orderId);
  if (!order) {
    return res.status(404).json({ error: 'Order not found.' });
  }

  // Only forward transitions from PENDING are honored, to avoid a replayed
  // or duplicate webhook flipping an already-resolved order.
  if (order.status !== 'PENDING') {
    return res.status(200).json({ ok: true, note: 'Order already resolved; ignoring.' });
  }

  const nextStatus = event.status === 'SUCCESS' ? 'SUCCESS' : 'FAILED';

  updateOrder(order.orderId, {
    status: nextStatus,
    transactionId: event.transactionId || null,
    providerOrderId: event.providerOrderId || order.providerOrderId,
  });

  return res.status(200).json({ ok: true });
}
