// POST /api/payment/create-payment
// Creates a PENDING order server-side and, if a real provider is
// configured, opens a payment session with it. In test mode, creates a
// clearly-labeled test order that cannot become SUCCESS on its own.

import { createOrder } from '../_lib/orderStore.js';
import { priceCartItems } from '../_lib/products.js';
import { generateOrderId } from '../_lib/ids.js';
import { createProviderPayment, isTestMode, getProviderName } from './_lib/provider.js';

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Method not allowed.' });
  }

  try {
    const { items, customerEmail, customerName } = req.body || {};

    if (!Array.isArray(items) || items.length === 0) {
      return res.status(400).json({ error: 'Your cart is empty.' });
    }
    if (!customerEmail || !/^\S+@\S+\.\S+$/.test(customerEmail)) {
      return res.status(400).json({ error: 'A valid email address is required.' });
    }

    // Recompute pricing from the server's own product data — never trust
    // amounts sent from the browser.
    let priced;
    try {
      priced = priceCartItems(items);
    } catch {
      return res.status(400).json({ error: 'One or more items in your cart are no longer available.' });
    }

    const orderId = generateOrderId();
    const currency = 'USD';

    const order = createOrder({
      orderId,
      items: priced.items,
      subtotal: priced.total,
      total: priced.total,
      currency,
      customerEmail,
      customerName: customerName || null,
      status: 'PENDING',
      paymentProvider: isTestMode() ? 'test-mode' : getProviderName(),
      providerOrderId: null,
      transactionId: null,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 15 * 60 * 1000).toISOString(), // 15 min window
    });

    const providerSession = await createProviderPayment({
      orderId,
      amount: priced.total,
      currency,
      customerEmail,
    });

    order.providerOrderId = providerSession.providerOrderId;

    return res.status(200).json({
      orderId: order.orderId,
      total: order.total,
      currency: order.currency,
      expiresAt: order.expiresAt,
      testMode: isTestMode(),
      provider: order.paymentProvider,
      clientConfig: providerSession.clientConfig,
    });
  } catch (err) {
    console.error('create-payment error:', err);
    return res.status(500).json({ error: 'We could not start your payment. Please try again.' });
  }
}
