// Payment provider abstraction.
//
// This is the ONLY file that should know which real payment gateway you're
// using. Every other file in the app calls the functions exported here,
// never a gateway's SDK directly. That means switching from Razorpay to
// Cashfree (or adding a second provider) never touches checkout UI, the
// order model, or the payment-status state machine.
//
// HOW TO ACTIVATE A REAL PROVIDER:
//   1. Set PAYMENT_PROVIDER=razorpay (or cashfree) in your environment.
//   2. Set that provider's API key/secret env vars (see .env.example).
//   3. Implement the two TODOs in createProviderPayment() and
//      verifyProviderWebhook() below using that provider's SDK/docs.
// Until both of those are done, the app safely runs in TEST_MODE and is
// incapable of reporting a real payment as successful.

const PROVIDER = process.env.PAYMENT_PROVIDER || 'none';

const REQUIRED_ENV_BY_PROVIDER = {
  razorpay: ['RAZORPAY_KEY_ID', 'RAZORPAY_KEY_SECRET', 'RAZORPAY_WEBHOOK_SECRET'],
  cashfree: ['CASHFREE_APP_ID', 'CASHFREE_SECRET_KEY', 'CASHFREE_WEBHOOK_SECRET'],
};

export function isProviderConfigured() {
  const required = REQUIRED_ENV_BY_PROVIDER[PROVIDER];
  if (!required) return false;
  return required.every((key) => Boolean(process.env[key]));
}

export function isTestMode() {
  return !isProviderConfigured();
}

export function getProviderName() {
  return PROVIDER === 'none' ? null : PROVIDER;
}

/**
 * Creates a payment session with the configured provider.
 * Returns { providerOrderId, clientConfig } where clientConfig is whatever
 * non-secret data the frontend needs to render the payment step (e.g. a
 * Razorpay order id + key id to open their checkout widget).
 *
 * In TEST_MODE this creates a clearly-labeled fake session that can never
 * transition an order to SUCCESS by itself — only the simulated webhook
 * endpoint (test-only, see /api/payment/dev-simulate.js) can do that, and
 * that route is disabled unless NODE_ENV !== 'production'.
 */
export async function createProviderPayment({ orderId, amount, currency, customerEmail }) {
  if (isTestMode()) {
    return {
      providerOrderId: `test_${orderId}`,
      testMode: true,
      clientConfig: {
        message: 'Payment gateway not configured — Test Mode',
        provider: 'none',
      },
    };
  }

  if (PROVIDER === 'razorpay') {
    // TODO: integrate the Razorpay Orders API here, e.g.
    //   const instance = new Razorpay({ key_id: process.env.RAZORPAY_KEY_ID, key_secret: process.env.RAZORPAY_KEY_SECRET });
    //   const order = await instance.orders.create({ amount: Math.round(amount * 100), currency, receipt: orderId });
    //   return { providerOrderId: order.id, testMode: false, clientConfig: { keyId: process.env.RAZORPAY_KEY_ID, providerOrderId: order.id, amount, currency } };
    throw new Error('Razorpay credentials detected but integration code is not yet implemented. See api/payment/_lib/provider.js.');
  }

  if (PROVIDER === 'cashfree') {
    // TODO: integrate the Cashfree Orders API here.
    throw new Error('Cashfree credentials detected but integration code is not yet implemented. See api/payment/_lib/provider.js.');
  }

  throw new Error(`Unknown PAYMENT_PROVIDER "${PROVIDER}".`);
}

/**
 * Verifies an incoming webhook call is genuinely from the configured
 * provider (signature check) and returns a normalized event, or null if
 * verification fails. Callers must treat a null return as "do not trust
 * this request" and must not update any order state.
 */
export async function verifyProviderWebhook({ headers, rawBody }) {
  if (isTestMode()) {
    // No real provider configured: there is nothing to verify against, so
    // no webhook from the outside world can ever be trusted in test mode.
    return null;
  }

  if (PROVIDER === 'razorpay') {
    // TODO: verify using Razorpay's webhook signature scheme, e.g.
    //   const signature = headers['x-razorpay-signature'];
    //   const expected = crypto.createHmac('sha256', process.env.RAZORPAY_WEBHOOK_SECRET).update(rawBody).digest('hex');
    //   if (signature !== expected) return null;
    //   const event = JSON.parse(rawBody);
    //   return { orderId: event.payload.order.entity.receipt, providerOrderId: event.payload.order.entity.id, status: mapRazorpayStatus(event.event), transactionId: event.payload.payment.entity.id };
    return null;
  }

  if (PROVIDER === 'cashfree') {
    // TODO: verify using Cashfree's webhook signature scheme.
    return null;
  }

  return null;
}
