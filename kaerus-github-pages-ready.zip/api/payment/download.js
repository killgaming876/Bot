// GET /api/payment/download?orderId=...&productId=...
// Only returns a download reference when the backend's own order record
// shows status === 'SUCCESS' for that order and that product. The frontend
// never constructs or stores a raw file URL itself.
//
// PRODUCTION TODO:
// Replace `buildDownloadReference()` below with real signed/temporary URLs
// from your storage provider (S3 presigned URL, Cloudflare R2, Google
// Cloud Storage signed URL, etc.), scoped to a short expiry. Never return a
// permanent public URL to private files.

import { getOrder } from '../_lib/orderStore.js';

function buildDownloadReference(orderId, productId) {
  // DEV/DEMO placeholder only — does not point at a real file. Swap this
  // for a signed URL generator once real storage is connected.
  return {
    kind: 'mock',
    note: 'This is a demo download reference. Connect real signed-URL storage before launch (see README).',
    fileName: `${productId}.zip`,
    expiresInSeconds: 600,
  };
}

export default async function handler(req, res) {
  if (req.method !== 'GET') {
    res.setHeader('Allow', 'GET');
    return res.status(405).json({ error: 'Method not allowed.' });
  }

  const { orderId, productId } = req.query;
  if (!orderId || !productId) {
    return res.status(400).json({ error: 'orderId and productId are required.' });
  }

  const order = getOrder(orderId);
  if (!order) {
    return res.status(404).json({ error: 'Order not found.' });
  }
  if (order.status !== 'SUCCESS') {
    return res.status(403).json({ error: 'This order has not been paid yet.' });
  }
  const owns = order.items.some((i) => i.id === productId);
  if (!owns) {
    return res.status(403).json({ error: 'This product is not part of that order.' });
  }

  const download = buildDownloadReference(orderId, productId);
  return res.status(200).json({ orderId, productId, download });
}
