// POST /api/payment/dev-simulate
// TEST-MODE ONLY. Lets you exercise the full create → pending → success/
// failed flow locally without a real payment gateway connected.
//
// This route is hard-disabled whenever:
//   - NODE_ENV === 'production', OR
//   - a real payment provider is actually configured (isTestMode() is false)
// It can NEVER run against a real customer transaction. It exists purely
// so you can click through Payment Status → Success/Failed pages while
// developing, using the one designated test product.
//
// This is intentionally the opposite of "frontend decides success": even
// this shortcut goes through a backend route that checks order state
// server-side before changing anything.

import { getOrder, updateOrder } from '../_lib/orderStore.js';
import { isTestMode } from './_lib/provider.js';

export default async function handler(req, res) {
  if (process.env.NODE_ENV === 'production') {
    return res.status(403).json({ error: 'Not available in production.' });
  }
  if (!isTestMode()) {
    return res.status(403).json({ error: 'A real payment provider is configured; simulation is disabled.' });
  }
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ error: 'Method not allowed.' });
  }

  const { orderId, outcome } = req.body || {};
  if (!orderId || !['SUCCESS', 'FAILED'].includes(outcome)) {
    return res.status(400).json({ error: 'orderId and a valid outcome (SUCCESS or FAILED) are required.' });
  }

  const order = getOrder(orderId);
  if (!order) {
    return res.status(404).json({ error: 'Order not found.' });
  }
  if (order.status !== 'PENDING') {
    return res.status(409).json({ error: `Order is already ${order.status}.` });
  }

  const updated = updateOrder(orderId, {
    status: outcome,
    transactionId: outcome === 'SUCCESS' ? `TEST-TXN-${Date.now()}` : null,
  });

  return res.status(200).json({ ok: true, status: updated.status });
}
