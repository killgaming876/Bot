// GET /api/payment/status?orderId=...
// The frontend polls this endpoint from the Payment Status page. It is the
// ONLY place the frontend learns whether a payment succeeded — there is no
// path in this app where the browser can set an order to SUCCESS itself.

import { getOrder, updateOrder } from '../_lib/orderStore.js';

export default async function handler(req, res) {
  if (req.method !== 'GET') {
    res.setHeader('Allow', 'GET');
    return res.status(405).json({ error: 'Method not allowed.' });
  }

  const { orderId } = req.query;
  if (!orderId) {
    return res.status(400).json({ error: 'orderId is required.' });
  }

  let order = getOrder(orderId);
  if (!order) {
    return res.status(404).json({ error: 'Order not found.' });
  }

  // Passive expiry check: if we're past the window and still pending,
  // flip to EXPIRED. This never touches SUCCESS/FAILED orders.
  if (order.status === 'PENDING' && order.expiresAt && new Date(order.expiresAt) < new Date()) {
    order = updateOrder(orderId, { status: 'EXPIRED' });
  }

  return res.status(200).json({
    orderId: order.orderId,
    status: order.status,
    total: order.total,
    currency: order.currency,
    items: order.items,
    customerEmail: order.customerEmail,
    transactionId: order.transactionId,
    provider: order.paymentProvider,
    createdAt: order.createdAt,
    updatedAt: order.updatedAt,
    expiresAt: order.expiresAt,
  });
}
