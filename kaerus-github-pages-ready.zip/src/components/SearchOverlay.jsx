import { useEffect, useRef, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { searchProducts } from '../data/products';
import ProductVisual from './ProductVisual';
import { formatPrice } from '../utils/pricing';
import './SearchOverlay.css';

export default function SearchOverlay({ open, onClose }) {
  const [query, setQuery] = useState('');
  const inputRef = useRef(null);
  const navigate = useNavigate();

  useEffect(() => {
    if (open) {
      setQuery('');
      setTimeout(() => inputRef.current?.focus(), 60);
      const onKey = (e) => e.key === 'Escape' && onClose();
      document.addEventListener('keydown', onKey);
      document.body.style.overflow = 'hidden';
      return () => {
        document.removeEventListener('keydown', onKey);
        document.body.style.overflow = '';
      };
    }
  }, [open, onClose]);

  const results = query.trim() ? searchProducts(query).slice(0, 6) : [];

  function goTo(id) {
    onClose();
    navigate(`/product/${id}`);
  }

  return (
    <AnimatePresence>
      {open && (
        <motion.div
          className="search-overlay"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.18 }}
          role="dialog"
          aria-modal="true"
          aria-label="Search products"
        >
          <div className="search-overlay__backdrop" onClick={onClose} />
          <motion.div
            className="search-overlay__panel"
            initial={{ y: -16, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: -16, opacity: 0 }}
            transition={{ duration: 0.22, ease: [0.16, 1, 0.3, 1] }}
          >
            <div className="search-overlay__field">
              <SearchIcon />
              <input
                ref={inputRef}
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Search products, categories, tags..."
                aria-label="Search query"
              />
              <button type="button" onClick={onClose} aria-label="Close search" className="search-overlay__close">
                <CloseIcon />
              </button>
            </div>

            {query.trim() && (
              <div className="search-overlay__results">
                {results.length === 0 ? (
                  <div className="search-overlay__empty">
                    <p>No products match &ldquo;{query}&rdquo;. Try a different term or browse the shop.</p>
                    <button type="button" className="btn btn--ghost" onClick={() => { onClose(); navigate('/shop'); }}>
                      Browse all products
                    </button>
                  </div>
                ) : (
                  results.map((p) => (
                    <button key={p.id} type="button" className="search-overlay__result" onClick={() => goTo(p.id)}>
                      <ProductVisual coverImage={p.coverImage} label={p.name} variant="thumb" className="search-overlay__thumb" />
                      <span className="search-overlay__resultinfo">
                        <span className="search-overlay__resultname">{p.name}</span>
                        <span className="search-overlay__resultmeta">{p.category}</span>
                      </span>
                      <span className="search-overlay__resultprice">{formatPrice(p.price)}</span>
                    </button>
                  ))
                )}
              </div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}

function SearchIcon() {
  return (
    <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
      <circle cx="11" cy="11" r="7" stroke="currentColor" strokeWidth="1.8" fill="none" />
      <path d="M21 21l-4.3-4.3" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}
function CloseIcon() {
  return (
    <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
      <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}
