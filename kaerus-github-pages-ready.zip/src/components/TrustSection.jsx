import { TRUST_ITEMS } from '../data/site';
import Reveal from './Reveal';
import './TrustSection.css';

const ICONS = {
  shield: <path d="M12 2l8 3.5v6c0 5-3.4 8.4-8 10.5-4.6-2.1-8-5.5-8-10.5v-6L12 2z" stroke="currentColor" strokeWidth="1.6" fill="none" strokeLinejoin="round" />,
  bolt: <path d="M13 2L4 14h6l-1 8 9-12h-6l1-8z" stroke="currentColor" strokeWidth="1.6" fill="none" strokeLinejoin="round" />,
  star: <path d="M12 2.5l3.1 6.6 7.2.9-5.3 5 1.4 7.2-6.4-3.5-6.4 3.5 1.4-7.2-5.3-5 7.2-.9z" stroke="currentColor" strokeWidth="1.6" fill="none" strokeLinejoin="round" />,
  message: <path d="M4 5h16v11H8l-4 4V5z" stroke="currentColor" strokeWidth="1.6" fill="none" strokeLinejoin="round" />,
};

export default function TrustSection() {
  return (
    <section className="trust">
      <div className="container trust__grid">
        {TRUST_ITEMS.map((item, i) => (
          <Reveal key={item.title} delay={i * 0.05} className="trust__item">
            <div className="trust__icon">
              <svg viewBox="0 0 24 24" width="22" height="22" aria-hidden="true">
                {ICONS[item.icon]}
              </svg>
            </div>
            <h3>{item.title}</h3>
            <p>{item.description}</p>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
