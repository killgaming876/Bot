import { useState } from 'react';
import { Link } from 'react-router-dom';
import { BRAND, FOOTER_LINKS } from '../data/site';
import './Footer.css';

export default function Footer() {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState(null); // null | 'success' | 'error'

  function handleSubmit(e) {
    e.preventDefault();
    if (!/^\S+@\S+\.\S+$/.test(email)) {
      setStatus('error');
      return;
    }
    setStatus('success');
    setEmail('');
  }

  return (
    <footer className="footer">
      <div className="container footer__top">
        <div className="footer__brand">
          <Link to="/" className="footer__logo">
            <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true">
              <path d="M6 3v18M6 12l8-9M6 12l9 9" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill="none" />
            </svg>
            <span>{BRAND.name}</span>
          </Link>
          <p className="footer__description">{BRAND.description}</p>
          <div className="footer__social">
            <a href="#" aria-label="Kaerus on X">
              <XIcon />
            </a>
            <a href="#" aria-label="Kaerus on Instagram">
              <InstagramIcon />
            </a>
            <a href="#" aria-label="Kaerus on YouTube">
              <YoutubeIcon />
            </a>
          </div>
        </div>

        {Object.entries(FOOTER_LINKS).map(([section, links]) => (
          <div className="footer__col" key={section}>
            <h3>{section}</h3>
            <ul>
              {links.map((link) => (
                <li key={link.label}>
                  <Link to={link.to}>{link.label}</Link>
                </li>
              ))}
            </ul>
          </div>
        ))}

        <div className="footer__newsletter">
          <h3>Stay in the loop</h3>
          <p>New products and occasional discounts. No spam.</p>
          <form onSubmit={handleSubmit} noValidate>
            <input
              type="email"
              placeholder="you@email.com"
              value={email}
              onChange={(e) => { setEmail(e.target.value); setStatus(null); }}
              aria-label="Email address"
              aria-invalid={status === 'error'}
            />
            <button type="submit">Subscribe</button>
          </form>
          {status === 'success' && <p className="footer__feedback footer__feedback--success">Subscribed — welcome aboard.</p>}
          {status === 'error' && <p className="footer__feedback footer__feedback--error">Enter a valid email address.</p>}
        </div>
      </div>

      <div className="container footer__bottom">
        <p>© {new Date().getFullYear()} {BRAND.name}. All rights reserved.</p>
        <p className="footer__tagline">{BRAND.tagline}</p>
      </div>
    </footer>
  );
}

function XIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">
      <path fill="currentColor" d="M17.5 3h3l-7.3 8.3L21.7 21h-6.7l-5.2-6.8L3.8 21H.8l7.8-8.9L2.3 3H9l4.7 6.2L17.5 3z" />
    </svg>
  );
}
function InstagramIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">
      <rect x="3" y="3" width="18" height="18" rx="5" stroke="currentColor" strokeWidth="1.8" fill="none" />
      <circle cx="12" cy="12" r="4" stroke="currentColor" strokeWidth="1.8" fill="none" />
      <circle cx="17.2" cy="6.8" r="1.1" fill="currentColor" />
    </svg>
  );
}
function YoutubeIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">
      <rect x="2" y="5.5" width="20" height="13" rx="4" stroke="currentColor" strokeWidth="1.8" fill="none" />
      <path d="M10 9.5l5 2.5-5 2.5v-5z" fill="currentColor" />
    </svg>
  );
}
