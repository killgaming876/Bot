import { motion } from 'framer-motion';
import Button from './Button';
import ProductVisual from './ProductVisual';
import { products } from '../data/products';
import './Hero.css';

const floatCards = [products[3], products[1], products[6]];

export default function Hero() {
  return (
    <section className="hero">
      <div className="container hero__inner">
        <motion.div
          className="hero__content"
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.7, ease: [0.16, 1, 0.3, 1] }}
        >
          <span className="hero__eyebrow">Digital products, made to be used</span>
          <h1 className="hero__title">
            Work built by people who actually ship it.
          </h1>
          <p className="hero__desc">
            Kaerus is a small, deliberate catalog of templates, guides, and tools —
            each one tested in a real workflow before it ever goes on the shelf.
          </p>
          <div className="hero__ctas">
            <Button variant="primary" size="lg" to="/shop">
              Explore Products
            </Button>
            <Button variant="secondary" size="lg" to="/shop?filter=bestseller">
              View Best Sellers
            </Button>
          </div>
        </motion.div>

        <motion.div
          className="hero__visual"
          initial={{ opacity: 0, scale: 0.96 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.8, delay: 0.15, ease: [0.16, 1, 0.3, 1] }}
        >
          <div className="hero__card hero__card--main">
            <ProductVisual coverImage={floatCards[0].coverImage} label={floatCards[0].name} variant="hero" />
            <div className="hero__cardlabel">
              <span>{floatCards[0].category}</span>
              <strong>{floatCards[0].name}</strong>
            </div>
          </div>
          <div className="hero__card hero__card--float1">
            <ProductVisual coverImage={floatCards[1].coverImage} label={floatCards[1].name} variant="thumb" />
          </div>
          <div className="hero__card hero__card--float2">
            <ProductVisual coverImage={floatCards[2].coverImage} label={floatCards[2].name} variant="thumb" />
          </div>
        </motion.div>
      </div>
    </section>
  );
}
