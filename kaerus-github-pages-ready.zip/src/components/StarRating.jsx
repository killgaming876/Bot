export default function StarRating({ rating, size = 15 }) {
  const stars = [1, 2, 3, 4, 5];
  return (
    <span style={{ display: 'inline-flex', gap: 2 }} aria-label={`${rating} out of 5 stars`}>
      {stars.map((s) => {
        const fill = Math.max(0, Math.min(1, rating - (s - 1)));
        return (
          <span key={s} style={{ position: 'relative', width: size, height: size, display: 'inline-block' }} aria-hidden="true">
            <svg viewBox="0 0 20 20" width={size} height={size} style={{ position: 'absolute', inset: 0 }}>
              <path fill="#2A2E38" d="M10 1.5l2.6 5.5 6 0.8-4.4 4.1 1.1 6-5.3-2.9-5.3 2.9 1.1-6L1.4 7.8l6-0.8z" />
            </svg>
            <span style={{ position: 'absolute', inset: 0, width: `${fill * 100}%`, overflow: 'hidden' }}>
              <svg viewBox="0 0 20 20" width={size} height={size}>
                <path fill="#E8B85C" d="M10 1.5l2.6 5.5 6 0.8-4.4 4.1 1.1 6-5.3-2.9-5.3 2.9 1.1-6L1.4 7.8l6-0.8z" />
              </svg>
            </span>
          </span>
        );
      })}
    </span>
  );
}
