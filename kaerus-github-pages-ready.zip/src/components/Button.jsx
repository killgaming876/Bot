import { useRef } from 'react';
import { Link } from 'react-router-dom';
import './Button.css';

// A restrained "magnetic" button: on pointer move, the label shifts a few
// pixels toward the cursor. Disabled automatically for touch/reduced motion.

export default function Button({
  as,
  to,
  href,
  variant = 'primary',
  size = 'md',
  children,
  className = '',
  magnetic = true,
  ...rest
}) {
  const ref = useRef(null);
  const prefersReduced = typeof window !== 'undefined' && window.matchMedia?.('(prefers-reduced-motion: reduce)').matches;

  function handleMove(e) {
    if (!magnetic || prefersReduced || !ref.current) return;
    const rect = ref.current.getBoundingClientRect();
    const x = e.clientX - rect.left - rect.width / 2;
    const y = e.clientY - rect.top - rect.height / 2;
    ref.current.style.setProperty('--mx', `${x * 0.18}px`);
    ref.current.style.setProperty('--my', `${y * 0.28}px`);
  }
  function handleLeave() {
    if (!ref.current) return;
    ref.current.style.setProperty('--mx', '0px');
    ref.current.style.setProperty('--my', '0px');
  }

  const classes = `btn btn--${variant} btn--${size} ${className}`;
  const Component = as === 'link' || to ? Link : 'button';
  const extraProps = to ? { to } : href ? { as: 'a', href } : {};

  return (
    <Component
      ref={ref}
      className={classes}
      onMouseMove={handleMove}
      onMouseLeave={handleLeave}
      {...extraProps}
      {...rest}
    >
      <span className="btn__label">{children}</span>
    </Component>
  );
}
