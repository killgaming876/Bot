import { AnimatePresence, motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';
import { useEffect } from 'react';
import { useCart } from '../context/CartContext';
import { useCheckout } from '../context/CheckoutContext';
import ProductVisual from './ProductVisual';
import Button from './Button';
import { formatPrice } from '../utils/pricing';
import './CartDrawer.css';

export default function CartDrawer() {
  const { items, totals, isDrawerOpen, closeDrawer, removeItem, setQuantity } = useCart();
  const { setIntentFromCart } = useCheckout();
  const navigate = useNavigate();

  useEffect(() => {
    if (isDrawerOpen) {
      document.body.style.overflow = 'hidden';
      const onKey = (e) => e.key === 'Escape' && closeDrawer();
      document.addEventListener('keydown', onKey);
      return () => {
        document.body.style.overflow = '';
        document.removeEventListener('keydown', onKey);
      };
    }
  }, [isDrawerOpen, closeDrawer]);

  function handleCheckout() {
    setIntentFromCart(items);
    closeDrawer();
    navigate('/checkout');
  }

  return (
    <AnimatePresence>
      {isDrawerOpen && (
        <div className="cart-drawer">
          <motion.div
            className="cart-drawer__backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.2 }}
            onClick={closeDrawer}
          />
          <motion.aside
            className="cart-drawer__panel"
            role="dialog"
            aria-modal="true"
            aria-label="Shopping cart"
            initial={{ x: '100%' }}
            animate={{ x: 0 }}
            exit={{ x: '100%' }}
            transition={{ duration: 0.32, ease: [0.16, 1, 0.3, 1] }}
          >
            <div className="cart-drawer__header">
              <h2>Your cart</h2>
              <button type="button" onClick={closeDrawer} aria-label="Close cart" className="cart-drawer__close">
                <CloseIcon />
              </button>
            </div>

            {items.length === 0 ? (
              <div className="cart-drawer__empty">
                <p>Your cart is empty.</p>
                <Button variant="secondary" onClick={closeDrawer} to="/shop">
                  Continue shopping
                </Button>
              </div>
            ) : (
              <>
                <ul className="cart-drawer__items">
                  {items.map((item) => (
                    <li key={item.id} className="cart-drawer__item">
                      <ProductVisual coverImage={item.coverImage} label={item.name} variant="thumb" className="cart-drawer__thumb" />
                      <div className="cart-drawer__iteminfo">
                        <p className="cart-drawer__itemname">{item.name}</p>
                        <p className="cart-drawer__itemcategory">{item.category}</p>
                        <div className="cart-drawer__qty">
                          <button
                            type="button"
                            aria-label="Decrease quantity"
                            onClick={() => setQuantity(item.id, item.quantity - 1)}
                          >
                            −
                          </button>
                          <span>{item.quantity}</span>
                          <button
                            type="button"
                            aria-label="Increase quantity"
                            onClick={() => setQuantity(item.id, item.quantity + 1)}
                          >
                            +
                          </button>
                        </div>
                      </div>
                      <div className="cart-drawer__itemright">
                        <span className="cart-drawer__itemprice">{formatPrice(item.price * item.quantity)}</span>
                        <button
                          type="button"
                          className="cart-drawer__remove"
                          onClick={() => removeItem(item.id)}
                        >
                          Remove
                        </button>
                      </div>
                    </li>
                  ))}
                </ul>

                <div className="cart-drawer__footer">
                  {totals.discount > 0 && (
                    <div className="cart-drawer__row">
                      <span>Discount</span>
                      <span className="cart-drawer__discount">−{formatPrice(totals.discount)}</span>
                    </div>
                  )}
                  <div className="cart-drawer__row cart-drawer__row--total">
                    <span>Total</span>
                    <span>{formatPrice(totals.total)}</span>
                  </div>
                  <Button variant="primary" size="lg" className="btn--full" onClick={handleCheckout}>
                    Checkout
                  </Button>
                  <Button variant="ghost" className="btn--full" onClick={closeDrawer} to="/shop">
                    Continue shopping
                  </Button>
                </div>
              </>
            )}
          </motion.aside>
        </div>
      )}
    </AnimatePresence>
  );
}

function CloseIcon() {
  return (
    <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true">
      <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}
