import { motion } from 'framer-motion';

// A single, restrained scroll-reveal primitive used deliberately (not on
// every element) to bring in section headers and key content once.

export default function Reveal({ children, delay = 0, y = 18, className = '', as = 'div' }) {
  const Component = motion[as] || motion.div;
  return (
    <Component
      className={className}
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-60px' }}
      transition={{ duration: 0.6, delay, ease: [0.16, 1, 0.3, 1] }}
    >
      {children}
    </Component>
  );
}
