import { STATS } from '../data/site';
import AnimatedNumber from './AnimatedNumber';
import Reveal from './Reveal';
import './StatsSection.css';

export default function StatsSection() {
  return (
    <section className="stats">
      <div className="container stats__grid">
        {STATS.map((stat, i) => (
          <Reveal key={stat.label} delay={i * 0.05} className="stats__item">
            <span className="stats__value">
              <AnimatedNumber value={stat.value} decimals={stat.decimals || 0} suffix={stat.suffix} />
            </span>
            <span className="stats__label">{stat.label}</span>
          </Reveal>
        ))}
      </div>
    </section>
  );
}
