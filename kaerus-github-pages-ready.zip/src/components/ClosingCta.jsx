import Reveal from './Reveal';
import Button from './Button';
import './ClosingCta.css';

export default function ClosingCta() {
  return (
    <section className="closing-cta">
      <div className="container">
        <Reveal className="closing-cta__inner">
          <h2>Find the thing that saves you the next ten hours.</h2>
          <p>Browse the full catalog — every product ships with a clear list of what's inside before you buy.</p>
          <Button variant="primary" size="lg" to="/shop">
            Explore Products
          </Button>
        </Reveal>
      </div>
    </section>
  );
}
