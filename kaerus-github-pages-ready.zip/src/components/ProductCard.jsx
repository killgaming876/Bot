import { useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import ProductVisual from './ProductVisual';
import { formatPrice } from '../utils/pricing';
import { useCart } from '../context/CartContext';
import { useCheckout } from '../context/CheckoutContext';
import './ProductCard.css';

export default function ProductCard({ product }) {
  const ref = useRef(null);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const { addItem } = useCart();
  const { setIntentFromBuyNow } = useCheckout();
  const navigate = useNavigate();

  function handleMove(e) {
    if (!ref.current || window.matchMedia?.('(prefers-reduced-motion: reduce)').matches) return;
    const rect = ref.current.getBoundingClientRect();
    const px = (e.clientX - rect.left) / rect.width - 0.5;
    const py = (e.clientY - rect.top) / rect.height - 0.5;
    setTilt({ x: py * -6, y: px * 8 });
  }
  function handleLeave() {
    setTilt({ x: 0, y: 0 });
  }

  function handleAddToCart(e) {
    e.preventDefault();
    addItem(product, 1);
  }

  function handleBuyNow(e) {
    e.preventDefault();
    setIntentFromBuyNow(product, 1);
    navigate('/checkout');
  }

  return (
    <Link
      to={`/product/${product.id}`}
      className="product-card"
      ref={ref}
      onMouseMove={handleMove}
      onMouseLeave={handleLeave}
      style={{ '--tilt-x': `${tilt.x}deg`, '--tilt-y': `${tilt.y}deg` }}
    >
      <div className="product-card__media">
        <ProductVisual coverImage={product.coverImage} label={product.name} />
        {product.badges?.length > 0 && (
          <div className="product-card__badges">
            {product.badges.map((b) => (
              <span key={b} className={`badge badge--${b.toLowerCase().replace(/\s+/g, '-')}`}>
                {b}
              </span>
            ))}
          </div>
        )}
        {product.discountPercent > 0 && (
          <span className="product-card__discount">−{product.discountPercent}%</span>
        )}
      </div>

      <div className="product-card__body">
        <span className="product-card__category">{product.category}</span>
        <h3 className="product-card__title">{product.name}</h3>
        <p className="product-card__desc">{product.shortDescription}</p>

        <div className="product-card__rating">
          <StarIcon />
          <span>{product.rating}</span>
          <span className="product-card__reviewcount">({product.reviewCount})</span>
        </div>

        <div className="product-card__footer">
          <div className="product-card__price">
            <span className="product-card__pricenow">{formatPrice(product.price)}</span>
            {product.originalPrice && (
              <span className="product-card__priceold">{formatPrice(product.originalPrice)}</span>
            )}
          </div>
          <div className="product-card__actions">
            <button type="button" className="product-card__actionbtn" onClick={handleAddToCart} aria-label={`Add ${product.name} to cart`}>
              <CartPlusIcon />
            </button>
            <button type="button" className="product-card__actionbtn product-card__actionbtn--primary" onClick={handleBuyNow}>
              Buy Now
            </button>
          </div>
        </div>
      </div>
    </Link>
  );
}

function StarIcon() {
  return (
    <svg viewBox="0 0 20 20" width="13" height="13" aria-hidden="true">
      <path fill="#E8B85C" d="M10 1.5l2.6 5.5 6 0.8-4.4 4.1 1.1 6-5.3-2.9-5.3 2.9 1.1-6L1.4 7.8l6-0.8z" />
    </svg>
  );
}
function CartPlusIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">
      <path d="M4 5h2l1.6 10.2a2 2 0 0 0 2 1.7h7.3a2 2 0 0 0 2-1.6L20 8H6.4" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" fill="none" />
      <circle cx="10" cy="20" r="1.2" fill="currentColor" />
      <circle cx="17" cy="20" r="1.2" fill="currentColor" />
    </svg>
  );
}
