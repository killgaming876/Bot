import { products } from '../data/products';
import ProductCard from './ProductCard';
import Reveal from './Reveal';
import Button from './Button';
import './FeaturedProducts.css';

export default function FeaturedProducts() {
  const featured = products.filter((p) => p.badges?.length > 0).slice(0, 4);

  return (
    <section className="featured">
      <div className="container">
        <Reveal className="featured__header">
          <div>
            <h2>Featured this week</h2>
            <p>A rotating shortlist of what people are actually buying.</p>
          </div>
          <Button variant="ghost" to="/shop">
            View all products →
          </Button>
        </Reveal>

        <div className="featured__grid">
          {featured.map((product, i) => (
            <Reveal key={product.id} delay={i * 0.06}>
              <ProductCard product={product} />
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}
