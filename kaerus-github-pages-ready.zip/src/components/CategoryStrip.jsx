import { Link } from 'react-router-dom';
import { CATEGORIES } from '../data/products';
import Reveal from './Reveal';
import './CategoryStrip.css';

export default function CategoryStrip() {
  return (
    <section className="cat-strip">
      <div className="container">
        <Reveal>
          <h2>Browse by category</h2>
        </Reveal>
        <div className="cat-strip__row">
          {CATEGORIES.map((cat, i) => (
            <Link key={cat} to={`/shop?category=${encodeURIComponent(cat)}`} className="cat-strip__pill">
              {cat}
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
}
