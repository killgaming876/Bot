import './ProductVisual.css';

// Each product references a "coverImage" key like 'gradient-3'. Rather than
// broken <img> placeholders, we render a distinct, deterministic abstract
// composition per product — consistent, on-brand, and replaceable later
// with real product photography/mockups by swapping this component for
// an <img src=...>.

const PALETTES = {
  1: ['#3D7FFF', '#1B2A4A'],
  2: ['#5EEAD4', '#123B39'],
  3: ['#A78BFA', '#241B4A'],
  4: ['#3D7FFF', '#0F1B33'],
  5: ['#F0B357', '#3A2A12'],
  6: ['#F0665A', '#3A1712'],
  7: ['#5EEAD4', '#0F2E2C'],
  8: ['#3D7FFF', '#141824'],
};

function paletteFor(key) {
  const n = String(key).match(/\d+/)?.[0] || '1';
  return PALETTES[n] || PALETTES[1];
}

export default function ProductVisual({ coverImage = 'gradient-1', label, className = '', variant = 'card' }) {
  const [c1, c2] = paletteFor(coverImage);
  const seed = String(coverImage).match(/\d+/)?.[0] || '1';

  return (
    <div
      className={`product-visual product-visual--${variant} ${className}`}
      style={{ '--pv-c1': c1, '--pv-c2': c2 }}
      role="img"
      aria-label={label ? `${label} cover artwork` : 'Product artwork'}
    >
      <svg viewBox="0 0 400 300" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
        <defs>
          <linearGradient id={`pv-grad-${seed}`} x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor={c2} />
            <stop offset="100%" stopColor="#0A0B0D" />
          </linearGradient>
        </defs>
        <rect width="400" height="300" fill={`url(#pv-grad-${seed})`} />
        <g opacity="0.9">
          <rect x={40 + (seed % 5) * 10} y="70" width="140" height="10" rx="5" fill={c1} opacity="0.85" />
          <rect x={40 + (seed % 5) * 10} y="94" width="90" height="10" rx="5" fill={c1} opacity="0.5" />
          <circle cx={300 - (seed % 4) * 12} cy="150" r="70" fill={c1} opacity="0.14" />
          <circle cx={300 - (seed % 4) * 12} cy="150" r="42" fill={c1} opacity="0.22" />
          <rect x={40 + (seed % 5) * 10} y="180" width="200" height="1" fill={c1} opacity="0.3" />
          <rect x={40 + (seed % 5) * 10} y="200" width="60" height="60" rx="10" fill="none" stroke={c1} strokeWidth="1.5" opacity="0.5" />
          <rect x={112 + (seed % 5) * 10} y="200" width="60" height="60" rx="10" fill={c1} opacity="0.12" stroke={c1} strokeWidth="1.5" strokeOpacity="0.4" />
        </g>
      </svg>
    </div>
  );
}
