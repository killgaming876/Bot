import { createContext, useCallback, useContext, useMemo, useState } from 'react';
import { readStorage, writeStorage } from '../utils/storage';

const OrdersContext = createContext(null);
const ORDERS_STORAGE_KEY = 'kaerus_orders_v1';

// IMPORTANT: this context only ever stores what the backend has told the
// client. It never sets a status to PAID/SUCCESS on its own — that value
// always comes from an API response (see api/payment/status.js). This file
// is a read cache for "my orders" UI, not a source of truth.

export function OrdersProvider({ children }) {
  const [orders, setOrders] = useState(() => readStorage(ORDERS_STORAGE_KEY, []));

  const upsertOrder = useCallback((order) => {
    setOrders((prev) => {
      const next = prev.filter((o) => o.orderId !== order.orderId);
      next.unshift(order);
      writeStorage(ORDERS_STORAGE_KEY, next);
      return next;
    });
  }, []);

  const getOrder = useCallback(
    (orderId) => orders.find((o) => o.orderId === orderId) || null,
    [orders]
  );

  const paidOrders = useMemo(() => orders.filter((o) => o.status === 'SUCCESS'), [orders]);

  const value = useMemo(
    () => ({ orders, paidOrders, upsertOrder, getOrder }),
    [orders, paidOrders, upsertOrder, getOrder]
  );

  return <OrdersContext.Provider value={value}>{children}</OrdersContext.Provider>;
}

export function useOrders() {
  const ctx = useContext(OrdersContext);
  if (!ctx) throw new Error('useOrders must be used within an OrdersProvider');
  return ctx;
}
