import { createContext, useCallback, useContext, useMemo, useState } from 'react';
import { readStorage, writeStorage, removeStorage } from '../utils/storage';
import { calculateCartTotals } from '../utils/pricing';

const CheckoutContext = createContext(null);
const CHECKOUT_STORAGE_KEY = 'kaerus_checkout_intent_v1';

// A "checkout intent" is the snapshot of items being purchased right now —
// either the whole cart, or a single Buy Now item. It's distinct from the
// cart itself so Buy Now doesn't have to touch cart state at all.

export function CheckoutProvider({ children }) {
  const [intent, setIntentState] = useState(() => readStorage(CHECKOUT_STORAGE_KEY, null));

  const setIntentFromCart = useCallback((cartItems) => {
    const snapshot = { source: 'cart', items: cartItems, createdAt: Date.now() };
    setIntentState(snapshot);
    writeStorage(CHECKOUT_STORAGE_KEY, snapshot);
  }, []);

  const setIntentFromBuyNow = useCallback((product, quantity = 1) => {
    const snapshot = {
      source: 'buy-now',
      items: [
        {
          id: product.id,
          name: product.name,
          price: product.price,
          originalPrice: product.originalPrice,
          coverImage: product.coverImage,
          category: product.category,
          quantity,
        },
      ],
      createdAt: Date.now(),
    };
    setIntentState(snapshot);
    writeStorage(CHECKOUT_STORAGE_KEY, snapshot);
  }, []);

  const clearIntent = useCallback(() => {
    setIntentState(null);
    removeStorage(CHECKOUT_STORAGE_KEY);
  }, []);

  const totals = useMemo(
    () => (intent?.items ? calculateCartTotals(intent.items) : { subtotal: 0, discount: 0, total: 0, itemCount: 0 }),
    [intent]
  );

  const value = useMemo(
    () => ({ intent, totals, setIntentFromCart, setIntentFromBuyNow, clearIntent }),
    [intent, totals, setIntentFromCart, setIntentFromBuyNow, clearIntent]
  );

  return <CheckoutContext.Provider value={value}>{children}</CheckoutContext.Provider>;
}

export function useCheckout() {
  const ctx = useContext(CheckoutContext);
  if (!ctx) throw new Error('useCheckout must be used within a CheckoutProvider');
  return ctx;
}
