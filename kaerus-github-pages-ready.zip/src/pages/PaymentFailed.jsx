import { useSearchParams, Link } from 'react-router-dom';
import Button from '../components/Button';
import './PaymentResult.css';

export default function PaymentFailed() {
  const [searchParams] = useSearchParams();
  const orderId = searchParams.get('orderId');

  return (
    <section className="payment-result">
      <div className="container payment-result__card">
        <div className="payment-result__icon payment-result__icon--failed">
          <CrossIcon />
        </div>
        <h1>Payment Failed</h1>
        <p className="payment-result__sub">
          Your transaction could not be completed{orderId ? ` for order ${orderId}` : ''}. You have not been
          charged, and this order has not been marked as paid.
        </p>
        <div className="payment-result__actions">
          <Button variant="primary" size="lg" to="/checkout">Try Again</Button>
          <Button variant="secondary" size="lg" to="/cart">Return to Cart</Button>
        </div>
      </div>
    </section>
  );
}

function CrossIcon() {
  return (
    <svg viewBox="0 0 24 24" width="30" height="30" aria-hidden="true">
      <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" />
    </svg>
  );
}
