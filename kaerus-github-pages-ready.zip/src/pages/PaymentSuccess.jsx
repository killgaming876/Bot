import { useEffect, useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useOrders } from '../context/OrdersContext';
import { getPaymentStatus } from '../utils/paymentApi';
import Button from '../components/Button';
import { formatPrice } from '../utils/pricing';
import './PaymentResult.css';

export default function PaymentSuccess() {
  const [searchParams] = useSearchParams();
  const orderId = searchParams.get('orderId');
  const { getOrder, upsertOrder } = useOrders();
  const [order, setOrder] = useState(() => (orderId ? getOrder(orderId) : null));
  const [verifying, setVerifying] = useState(true);
  const [verifyError, setVerifyError] = useState(null);

  // Re-verify with the backend on load rather than trusting only what's in
  // local cache or the URL — a refresh or revisit must not show "success"
  // unless the backend still reports SUCCESS right now.
  useEffect(() => {
    if (!orderId) {
      setVerifying(false);
      return;
    }
    getPaymentStatus(orderId)
      .then((data) => {
        upsertOrder({
          orderId: data.orderId,
          status: data.status,
          total: data.total,
          currency: data.currency,
          items: data.items,
          customerEmail: data.customerEmail,
          transactionId: data.transactionId,
          provider: data.provider,
          updatedAt: data.updatedAt,
        });
        setOrder(data);
      })
      .catch(() => setVerifyError('Could not confirm your payment status right now.'))
      .finally(() => setVerifying(false));
  }, [orderId]);

  if (verifying) {
    return (
      <div className="container payment-result__loading">
        <p>Confirming your payment…</p>
      </div>
    );
  }

  if (!order || order.status !== 'SUCCESS') {
    return (
      <div className="container payment-result__loading">
        <p>{verifyError || "We couldn't confirm a successful payment for this order."}</p>
        <Button variant="secondary" to="/cart">Return to cart</Button>
      </div>
    );
  }

  return (
    <section className="payment-result">
      <div className="container payment-result__card">
        <motion.div
          className="payment-result__icon payment-result__icon--success"
          initial={{ scale: 0.6, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] }}
        >
          <CheckIcon />
        </motion.div>

        <h1>Payment Successful</h1>
        <p className="payment-result__sub">Your digital product is ready.</p>

        <div className="payment-result__details">
          <div><span>Order number</span><strong>{order.orderId}</strong></div>
          <div><span>Amount paid</span><strong>{formatPrice(order.total, order.currency)}</strong></div>
          <div><span>Purchase date</span><strong>{new Date(order.updatedAt || Date.now()).toLocaleDateString()}</strong></div>
          <div><span>Email</span><strong>{order.customerEmail}</strong></div>
          {order.transactionId && <div><span>Transaction ref</span><strong>{order.transactionId}</strong></div>}
        </div>

        <ul className="payment-result__products">
          {order.items.map((item) => (
            <li key={item.id}>{item.name}</li>
          ))}
        </ul>

        <div className="payment-result__actions">
          <Button variant="primary" size="lg" to={`/my-products?orderId=${encodeURIComponent(order.orderId)}`}>
            Download Product
          </Button>
          <Button variant="secondary" size="lg" to="/my-products">
            View My Products
          </Button>
        </div>
      </div>
    </section>
  );
}

function CheckIcon() {
  return (
    <svg viewBox="0 0 24 24" width="34" height="34" aria-hidden="true">
      <path d="M5 12.5l4.5 4.5L19 7" stroke="currentColor" strokeWidth="2.4" fill="none" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
