import PageHeader from '../components/PageHeader';
import StatsSection from '../components/StatsSection';
import { BRAND } from '../data/site';
import './StaticPage.css';

export default function About() {
  return (
    <>
      <PageHeader eyebrow="About" title={`About ${BRAND.name}`} description={BRAND.description} />
      <section className="static-page">
        <div className="container static-page__prose">
          <p>
            {BRAND.name} started from a simple frustration: most digital products are either
            padded out to justify a price tag, or so bare-bones they leave you doing half the
            work yourself. We build the middle ground — resources sized to be actually used,
            not just downloaded and forgotten.
          </p>
          <p>
            Every product in the catalog goes through the same filter: would we personally use
            this in our own work? If the answer isn't a clear yes, it doesn't get listed. That's
            also why the catalog stays deliberately small — a few dozen products we stand behind,
            rather than hundreds we don't.
          </p>
          <h2>How we work</h2>
          <p>
            We build in the open about what each product includes — file types, sizes, what's
            inside — before you ever reach checkout. No surprises after payment, no vague
            "bundle" language hiding thin content.
          </p>
          <h2>Support that's actually support</h2>
          <p>
            Questions about a product, a purchase, or a refund reach a real person through our
            Contact page. We read everything and aim to reply within one business day.
          </p>
        </div>
      </section>
      <StatsSection />
    </>
  );
}
