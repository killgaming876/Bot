import { Link } from 'react-router-dom';
import Button from '../components/Button';
import './StaticPage.css';

export default function NotFound() {
  return (
    <section className="static-page">
      <div className="container static-page__prose" style={{ alignItems: 'flex-start' }}>
        <h2>Page not found</h2>
        <p>The page or product you're looking for doesn't exist or may have been removed.</p>
        <Button variant="primary" to="/">Back to home</Button>
      </div>
    </section>
  );
}
