import Hero from '../components/Hero';
import TrustSection from '../components/TrustSection';
import FeaturedProducts from '../components/FeaturedProducts';
import CategoryStrip from '../components/CategoryStrip';
import StatsSection from '../components/StatsSection';
import ClosingCta from '../components/ClosingCta';

export default function Home() {
  return (
    <>
      <Hero />
      <TrustSection />
      <FeaturedProducts />
      <CategoryStrip />
      <StatsSection />
      <ClosingCta />
    </>
  );
}
