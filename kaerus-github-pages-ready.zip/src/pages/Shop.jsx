import { useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { products, CATEGORIES } from '../data/products';
import ProductCard from '../components/ProductCard';
import PageHeader from '../components/PageHeader';
import Reveal from '../components/Reveal';
import './Shop.css';

const SORT_OPTIONS = [
  { value: 'featured', label: 'Featured' },
  { value: 'newest', label: 'Newest' },
  { value: 'bestselling', label: 'Bestselling' },
  { value: 'price-asc', label: 'Price: Low to High' },
  { value: 'price-desc', label: 'Price: High to Low' },
  { value: 'rating', label: 'Highest Rated' },
];

export default function Shop() {
  const [searchParams, setSearchParams] = useSearchParams();
  const [query, setQuery] = useState('');
  const [category, setCategory] = useState(searchParams.get('category') || 'All');
  const [sort, setSort] = useState('featured');
  const [maxPrice, setMaxPrice] = useState(60);
  const [minRating, setMinRating] = useState(0);
  const [discountedOnly, setDiscountedOnly] = useState(false);
  const filterParam = searchParams.get('filter');

  const filtered = useMemo(() => {
    let list = [...products];

    if (filterParam === 'bestseller') {
      list = list.filter((p) => p.badges?.includes('Bestseller'));
    }

    if (query.trim()) {
      const q = query.trim().toLowerCase();
      list = list.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.shortDescription.toLowerCase().includes(q) ||
          p.tags.some((t) => t.toLowerCase().includes(q))
      );
    }

    if (category !== 'All') {
      list = list.filter((p) => p.category === category);
    }

    list = list.filter((p) => p.price <= maxPrice);
    list = list.filter((p) => p.rating >= minRating);
    if (discountedOnly) {
      list = list.filter((p) => p.discountPercent > 0);
    }

    switch (sort) {
      case 'newest':
        list = list.filter((p) => p.badges?.includes('New')).concat(list.filter((p) => !p.badges?.includes('New')));
        break;
      case 'bestselling':
        list.sort((a, b) => b.salesCount - a.salesCount);
        break;
      case 'price-asc':
        list.sort((a, b) => a.price - b.price);
        break;
      case 'price-desc':
        list.sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        list.sort((a, b) => b.rating - a.rating);
        break;
      default:
        break;
    }

    return list;
  }, [query, category, sort, maxPrice, minRating, discountedOnly, filterParam]);

  function handleCategoryClick(cat) {
    setCategory(cat);
    const next = new URLSearchParams(searchParams);
    if (cat === 'All') next.delete('category');
    else next.set('category', cat);
    setSearchParams(next, { replace: true });
  }

  return (
    <>
      <PageHeader
        eyebrow="Shop"
        title="The full catalog"
        description="Every product listed here has a full breakdown of what's included before you buy — no surprises after checkout."
      />

      <section className="shop">
        <div className="container shop__layout">
          <aside className="shop__filters">
            <div className="shop__filtergroup">
              <label htmlFor="shop-search">Search</label>
              <input
                id="shop-search"
                type="text"
                placeholder="Search products..."
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
            </div>

            <div className="shop__filtergroup">
              <span className="shop__filterlabel">Category</span>
              <div className="shop__categories">
                <button
                  type="button"
                  className={category === 'All' ? 'active' : ''}
                  onClick={() => handleCategoryClick('All')}
                >
                  All
                </button>
                {CATEGORIES.map((cat) => (
                  <button
                    key={cat}
                    type="button"
                    className={category === cat ? 'active' : ''}
                    onClick={() => handleCategoryClick(cat)}
                  >
                    {cat}
                  </button>
                ))}
              </div>
            </div>

            <div className="shop__filtergroup">
              <label htmlFor="shop-price">Max price: ${maxPrice}</label>
              <input
                id="shop-price"
                type="range"
                min="15"
                max="60"
                value={maxPrice}
                onChange={(e) => setMaxPrice(Number(e.target.value))}
              />
            </div>

            <div className="shop__filtergroup">
              <span className="shop__filterlabel">Minimum rating</span>
              <div className="shop__categories">
                {[0, 4, 4.5, 4.8].map((r) => (
                  <button
                    key={r}
                    type="button"
                    className={minRating === r ? 'active' : ''}
                    onClick={() => setMinRating(r)}
                  >
                    {r === 0 ? 'Any' : `${r}+`}
                  </button>
                ))}
              </div>
            </div>

            <label className="shop__checkbox">
              <input
                type="checkbox"
                checked={discountedOnly}
                onChange={(e) => setDiscountedOnly(e.target.checked)}
              />
              Discounted only
            </label>
          </aside>

          <div className="shop__main">
            <div className="shop__toolbar">
              <span className="shop__count">{filtered.length} product{filtered.length === 1 ? '' : 's'}</span>
              <div className="shop__sort">
                <label htmlFor="shop-sort">Sort by</label>
                <select id="shop-sort" value={sort} onChange={(e) => setSort(e.target.value)}>
                  {SORT_OPTIONS.map((opt) => (
                    <option key={opt.value} value={opt.value}>
                      {opt.label}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            {filtered.length === 0 ? (
              <div className="shop__noresults">
                <p>No products match your filters right now.</p>
                <button
                  type="button"
                  onClick={() => {
                    setQuery('');
                    setCategory('All');
                    setMaxPrice(60);
                    setMinRating(0);
                    setDiscountedOnly(false);
                  }}
                >
                  Clear all filters
                </button>
              </div>
            ) : (
              <div className="shop__grid">
                {filtered.map((product, i) => (
                  <Reveal key={product.id} delay={Math.min(i, 6) * 0.04}>
                    <ProductCard product={product} />
                  </Reveal>
                ))}
              </div>
            )}
          </div>
        </div>
      </section>
    </>
  );
}
