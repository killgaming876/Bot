import PageHeader from '../components/PageHeader';
import { SITE_FAQ } from '../data/site';
import './StaticPage.css';
import './Faq.css';

export default function Faq() {
  return (
    <>
      <PageHeader eyebrow="FAQ" title="Frequently asked questions" description="Common questions about buying and downloading digital products from Kaerus." />
      <section className="static-page">
        <div className="container faq__list">
          {SITE_FAQ.map((item) => (
            <details key={item.q} className="faq__item">
              <summary>{item.q}</summary>
              <p>{item.a}</p>
            </details>
          ))}
        </div>
      </section>
    </>
  );
}
