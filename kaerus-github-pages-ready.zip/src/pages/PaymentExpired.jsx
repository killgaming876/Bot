import { useSearchParams } from 'react-router-dom';
import Button from '../components/Button';
import './PaymentResult.css';

export default function PaymentExpired() {
  const [searchParams] = useSearchParams();
  const orderId = searchParams.get('orderId');

  return (
    <section className="payment-result">
      <div className="container payment-result__card">
        <div className="payment-result__icon payment-result__icon--expired">
          <ClockIcon />
        </div>
        <h1>Payment Session Expired</h1>
        <p className="payment-result__sub">
          The payment window for{orderId ? ` order ${orderId}` : ' this order'} has closed. No charge was made.
        </p>
        <div className="payment-result__actions">
          <Button variant="primary" size="lg" to="/checkout">Start New Payment</Button>
          <Button variant="secondary" size="lg" to="/shop">Return to Store</Button>
        </div>
      </div>
    </section>
  );
}

function ClockIcon() {
  return (
    <svg viewBox="0 0 24 24" width="30" height="30" aria-hidden="true">
      <circle cx="12" cy="12" r="9" stroke="currentColor" strokeWidth="2" fill="none" />
      <path d="M12 7v5l3.5 2" stroke="currentColor" strokeWidth="2" strokeLinecap="round" fill="none" />
    </svg>
  );
}
