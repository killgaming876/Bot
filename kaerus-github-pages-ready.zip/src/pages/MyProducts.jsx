import { useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useOrders } from '../context/OrdersContext';
import PageHeader from '../components/PageHeader';
import ProductVisual from '../components/ProductVisual';
import Button from '../components/Button';
import { getDownload, PaymentApiError } from '../utils/paymentApi';
import { formatPrice } from '../utils/pricing';
import './MyProducts.css';

export default function MyProducts() {
  const { paidOrders } = useOrders();
  const [searchParams] = useSearchParams();
  const highlightOrderId = searchParams.get('orderId');
  const [downloadState, setDownloadState] = useState({}); // key: orderId:productId

  async function handleDownload(orderId, productId) {
    const key = `${orderId}:${productId}`;
    setDownloadState((s) => ({ ...s, [key]: { status: 'loading' } }));
    try {
      const result = await getDownload(orderId, productId);
      setDownloadState((s) => ({ ...s, [key]: { status: 'ready', data: result.download } }));
    } catch (err) {
      const message = err instanceof PaymentApiError ? err.message : 'Download unavailable right now.';
      setDownloadState((s) => ({ ...s, [key]: { status: 'error', message } }));
    }
  }

  const purchasedItems = paidOrders.flatMap((order) =>
    order.items.map((item) => ({ order, item }))
  );

  return (
    <>
      <PageHeader
        eyebrow="My Products"
        title="Your downloads"
        description="Everything you've purchased, in one place. Downloads never expire."
      />

      <section className="my-products">
        <div className="container">
          {purchasedItems.length === 0 ? (
            <div className="my-products__empty">
              <p>You haven't purchased anything yet — or your orders aren't linked to this device.</p>
              <Button variant="primary" to="/shop">Browse products</Button>
            </div>
          ) : (
            <ul className="my-products__list">
              {purchasedItems.map(({ order, item }) => {
                const key = `${order.orderId}:${item.id}`;
                const state = downloadState[key];
                const isHighlighted = order.orderId === highlightOrderId;
                return (
                  <li key={key} className={`my-products__item ${isHighlighted ? 'highlighted' : ''}`}>
                    <ProductVisual coverImage={item.coverImage} label={item.name} variant="thumb" className="my-products__thumb" />
                    <div className="my-products__info">
                      <span className="my-products__name">{item.name}</span>
                      <span className="my-products__meta">
                        Order {order.orderId} · {formatPrice(item.price * item.quantity)} · Purchased{' '}
                        {order.updatedAt ? new Date(order.updatedAt).toLocaleDateString() : ''}
                      </span>
                    </div>
                    <div className="my-products__action">
                      {!state && (
                        <Button variant="secondary" size="sm" onClick={() => handleDownload(order.orderId, item.id)}>
                          Get Download
                        </Button>
                      )}
                      {state?.status === 'loading' && <span className="my-products__status">Preparing…</span>}
                      {state?.status === 'ready' && (
                        <span className="my-products__ready">
                          <CheckIcon /> {state.data.fileName} ready
                          <em>({state.data.note})</em>
                        </span>
                      )}
                      {state?.status === 'error' && (
                        <span className="my-products__errormsg">{state.message}</span>
                      )}
                    </div>
                  </li>
                );
              })}
            </ul>
          )}
        </div>
      </section>
    </>
  );
}

function CheckIcon() {
  return (
    <svg viewBox="0 0 24 24" width="15" height="15" aria-hidden="true">
      <path d="M5 12.5l4.5 4.5L19 7" stroke="#5EEAD4" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
