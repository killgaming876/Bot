import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useCheckout } from '../context/CheckoutContext';
import ProductVisual from '../components/ProductVisual';
import Button from '../components/Button';
import PageHeader from '../components/PageHeader';
import { formatPrice } from '../utils/pricing';
import './Cart.css';

export default function Cart() {
  const { items, totals, removeItem, setQuantity } = useCart();
  const { setIntentFromCart } = useCheckout();
  const navigate = useNavigate();

  function handleCheckout() {
    setIntentFromCart(items);
    navigate('/checkout');
  }

  if (items.length === 0) {
    return (
      <>
        <PageHeader eyebrow="Cart" title="Your cart is empty" />
        <div className="container cart-empty">
          <p>Looks like you haven't added anything yet.</p>
          <Button variant="primary" size="lg" to="/shop">
            Browse products
          </Button>
        </div>
      </>
    );
  }

  return (
    <>
      <PageHeader eyebrow="Cart" title="Your cart" description={`${totals.itemCount} item${totals.itemCount === 1 ? '' : 's'} ready for checkout.`} />

      <section className="cart-page">
        <div className="container cart-page__layout">
          <ul className="cart-page__items">
            {items.map((item) => (
              <li key={item.id} className="cart-page__item">
                <ProductVisual coverImage={item.coverImage} label={item.name} variant="thumb" className="cart-page__thumb" />
                <div className="cart-page__info">
                  <Link to={`/product/${item.id}`} className="cart-page__name">{item.name}</Link>
                  <span className="cart-page__category">{item.category}</span>
                </div>
                <div className="cart-page__qty">
                  <button type="button" onClick={() => setQuantity(item.id, item.quantity - 1)} aria-label="Decrease quantity">−</button>
                  <span>{item.quantity}</span>
                  <button type="button" onClick={() => setQuantity(item.id, item.quantity + 1)} aria-label="Increase quantity">+</button>
                </div>
                <span className="cart-page__price">{formatPrice(item.price * item.quantity)}</span>
                <button type="button" className="cart-page__remove" onClick={() => removeItem(item.id)} aria-label={`Remove ${item.name}`}>
                  <CloseIcon />
                </button>
              </li>
            ))}
          </ul>

          <aside className="cart-page__summary">
            <h2>Order summary</h2>
            <div className="cart-page__row">
              <span>Subtotal</span>
              <span>{formatPrice(totals.subtotal)}</span>
            </div>
            {totals.discount > 0 && (
              <div className="cart-page__row cart-page__row--discount">
                <span>Discount</span>
                <span>−{formatPrice(totals.discount)}</span>
              </div>
            )}
            <div className="cart-page__row cart-page__row--total">
              <span>Total</span>
              <span>{formatPrice(totals.total)}</span>
            </div>
            <Button variant="primary" size="lg" className="btn--full" onClick={handleCheckout}>
              Proceed to Checkout
            </Button>
            <Button variant="ghost" className="btn--full" to="/shop">
              Continue shopping
            </Button>
          </aside>
        </div>
      </section>
    </>
  );
}

function CloseIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">
      <path d="M6 6l12 12M18 6L6 18" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" />
    </svg>
  );
}
