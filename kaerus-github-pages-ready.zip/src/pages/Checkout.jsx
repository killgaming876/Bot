import { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useCheckout } from '../context/CheckoutContext';
import { useOrders } from '../context/OrdersContext';
import ProductVisual from '../components/ProductVisual';
import Button from '../components/Button';
import PageHeader from '../components/PageHeader';
import { formatPrice } from '../utils/pricing';
import { createPayment, PaymentApiError } from '../utils/paymentApi';
import './Checkout.css';

export default function Checkout() {
  const { intent, totals, clearIntent } = useCheckout();
  const { upsertOrder } = useOrders();
  const navigate = useNavigate();

  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [agreed, setAgreed] = useState(false);
  const [errors, setErrors] = useState({});
  const [submitting, setSubmitting] = useState(false);
  const [apiError, setApiError] = useState(null);

  if (!intent || !intent.items || intent.items.length === 0) {
    return (
      <>
        <PageHeader eyebrow="Checkout" title="Nothing to check out yet" />
        <div className="container checkout-empty">
          <p>Your checkout session is empty. Add a product from the shop to continue.</p>
          <Button variant="primary" size="lg" to="/shop">
            Browse products
          </Button>
        </div>
      </>
    );
  }

  function validate() {
    const next = {};
    if (!email.trim() || !/^\S+@\S+\.\S+$/.test(email)) {
      next.email = 'Enter a valid email address.';
    }
    if (!agreed) {
      next.agreed = 'You must accept the terms to continue.';
    }
    setErrors(next);
    return Object.keys(next).length === 0;
  }

  async function handlePay(e) {
    e.preventDefault();
    setApiError(null);
    if (!validate()) return;

    setSubmitting(true);
    try {
      const result = await createPayment({
        items: intent.items.map((i) => ({ id: i.id, quantity: i.quantity })),
        customerEmail: email.trim(),
        customerName: name.trim() || undefined,
      });

      upsertOrder({
        orderId: result.orderId,
        status: 'PENDING',
        total: result.total,
        currency: result.currency,
        items: intent.items,
        customerEmail: email.trim(),
        provider: result.provider,
        testMode: result.testMode,
        createdAt: new Date().toISOString(),
      });

      clearIntent();
      navigate(`/payment-status?orderId=${encodeURIComponent(result.orderId)}`);
    } catch (err) {
      if (err instanceof PaymentApiError) {
        setApiError(err.message);
      } else {
        setApiError('Something went wrong starting your payment. Please try again.');
      }
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <>
      <PageHeader eyebrow="Checkout" title="Complete your purchase" />

      <section className="checkout">
        <div className="container checkout__layout">
          <form className="checkout__form" onSubmit={handlePay} noValidate>
            <div className="checkout__section">
              <h2>Contact information</h2>
              <div className="checkout__field">
                <label htmlFor="checkout-email">Email address *</label>
                <input
                  id="checkout-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="you@email.com"
                  aria-invalid={Boolean(errors.email)}
                  aria-describedby={errors.email ? 'checkout-email-error' : undefined}
                />
                {errors.email && <span className="checkout__error" id="checkout-email-error">{errors.email}</span>}
                <p className="checkout__hint">Your download link and receipt will be sent here.</p>
              </div>
              <div className="checkout__field">
                <label htmlFor="checkout-name">Full name (optional)</label>
                <input
                  id="checkout-name"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="Jane Doe"
                />
              </div>
            </div>

            <div className="checkout__section">
              <h2>Payment</h2>
              <div className="checkout__paymentnotice">
                <ShieldIcon />
                <div>
                  <strong>Secure payment</strong>
                  <p>Digital products only — no shipping information needed. Your download unlocks immediately once payment is verified by our payment provider.</p>
                </div>
              </div>
            </div>

            <label className="checkout__terms">
              <input
                type="checkbox"
                checked={agreed}
                onChange={(e) => setAgreed(e.target.checked)}
                aria-invalid={Boolean(errors.agreed)}
              />
              <span>
                I agree to the Terms &amp; Conditions and Refund Policy.
              </span>
            </label>
            {errors.agreed && <span className="checkout__error">{errors.agreed}</span>}

            {apiError && <div className="checkout__apierror">{apiError}</div>}

            <Button variant="primary" size="lg" className="btn--full" type="submit" disabled={submitting}>
              {submitting ? 'Starting payment…' : `Pay ${formatPrice(totals.total)}`}
            </Button>
          </form>

          <aside className="checkout__summary">
            <h2>Order summary</h2>
            <ul>
              {intent.items.map((item) => (
                <li key={item.id}>
                  <ProductVisual coverImage={item.coverImage} label={item.name} variant="thumb" className="checkout__thumb" />
                  <div className="checkout__summaryinfo">
                    <span className="checkout__summaryname">{item.name}</span>
                    <span className="checkout__summaryqty">Qty {item.quantity}</span>
                  </div>
                  <span className="checkout__summaryprice">{formatPrice(item.price * item.quantity)}</span>
                </li>
              ))}
            </ul>
            <div className="checkout__row">
              <span>Subtotal</span>
              <span>{formatPrice(totals.subtotal)}</span>
            </div>
            {totals.discount > 0 && (
              <div className="checkout__row checkout__row--discount">
                <span>Discount</span>
                <span>−{formatPrice(totals.discount)}</span>
              </div>
            )}
            <div className="checkout__row checkout__row--total">
              <span>Total</span>
              <span>{formatPrice(totals.total)}</span>
            </div>
            <div className="checkout__badges">
              <span><BoltIcon /> Instant delivery</span>
              <span><ShieldIcon /> Purchase protection</span>
            </div>
          </aside>
        </div>
      </section>
    </>
  );
}

function ShieldIcon() {
  return (
    <svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true">
      <path d="M12 2l8 3.5v6c0 5-3.4 8.4-8 10.5-4.6-2.1-8-5.5-8-10.5v-6L12 2z" stroke="currentColor" strokeWidth="1.6" fill="none" strokeLinejoin="round" />
    </svg>
  );
}
function BoltIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">
      <path d="M13 2L4 14h6l-1 8 9-12h-6l1-8z" stroke="currentColor" strokeWidth="1.6" fill="none" strokeLinejoin="round" />
    </svg>
  );
}
