import { useCallback, useEffect, useRef, useState } from 'react';
import { useSearchParams, useNavigate, Link } from 'react-router-dom';
import { getPaymentStatus } from '../utils/paymentApi';
import { useOrders } from '../context/OrdersContext';
import Button from '../components/Button';
import { formatPrice } from '../utils/pricing';
import './PaymentStatus.css';

const POLL_INTERVAL_MS = 3000;

export default function PaymentStatus() {
  const [searchParams] = useSearchParams();
  const orderId = searchParams.get('orderId');
  const navigate = useNavigate();
  const { upsertOrder } = useOrders();

  const [order, setOrder] = useState(null);
  const [error, setError] = useState(null);
  const [secondsLeft, setSecondsLeft] = useState(null);
  const pollRef = useRef(null);
  const isTestModeRef = useRef(false);

  const poll = useCallback(async () => {
    if (!orderId) return;
    try {
      const data = await getPaymentStatus(orderId);
      setOrder(data);
      isTestModeRef.current = data.provider === 'test-mode';

      if (data.expiresAt) {
        const remaining = Math.max(0, Math.floor((new Date(data.expiresAt) - Date.now()) / 1000));
        setSecondsLeft(remaining);
      }

      upsertOrder({
        orderId: data.orderId,
        status: data.status,
        total: data.total,
        currency: data.currency,
        items: data.items,
        customerEmail: data.customerEmail,
        transactionId: data.transactionId,
        provider: data.provider,
        updatedAt: data.updatedAt,
      });

      // Only the backend response can move us forward. We simply reflect
      // whatever status it reports — there is no client-side "mark as paid".
      if (data.status === 'SUCCESS') {
        navigate(`/payment-success?orderId=${encodeURIComponent(orderId)}`, { replace: true });
      } else if (data.status === 'FAILED') {
        navigate(`/payment-failed?orderId=${encodeURIComponent(orderId)}`, { replace: true });
      } else if (data.status === 'EXPIRED') {
        navigate(`/payment-expired?orderId=${encodeURIComponent(orderId)}`, { replace: true });
      }
    } catch (err) {
      setError(err.message || 'Could not check payment status.');
    }
  }, [orderId, navigate, upsertOrder]);

  useEffect(() => {
    if (!orderId) return;
    poll();
    pollRef.current = setInterval(poll, POLL_INTERVAL_MS);
    return () => clearInterval(pollRef.current);
  }, [orderId, poll]);

  useEffect(() => {
    if (secondsLeft === null) return;
    const t = setInterval(() => setSecondsLeft((s) => (s !== null ? Math.max(0, s - 1) : s)), 1000);
    return () => clearInterval(t);
  }, [secondsLeft !== null]);

  if (!orderId) {
    return (
      <div className="container payment-status__missing">
        <p>No order specified.</p>
        <Button variant="primary" to="/shop">Back to shop</Button>
      </div>
    );
  }

  const minutes = secondsLeft !== null ? Math.floor(secondsLeft / 60) : null;
  const seconds = secondsLeft !== null ? secondsLeft % 60 : null;

  async function handleDevSimulate(outcome) {
    try {
      await fetch('/api/payment/dev-simulate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ orderId, outcome }),
      });
      poll();
    } catch {
      setError('Could not simulate outcome.');
    }
  }

  return (
    <section className="payment-status">
      <div className="container payment-status__card">
        <div className="payment-status__spinner" aria-hidden="true" />
        <h1>Waiting for payment…</h1>
        <p className="payment-status__sub">Do not close this window. This page updates automatically.</p>

        {order && (
          <>
            <div className="payment-status__details">
              <div>
                <span>Order ID</span>
                <strong>{order.orderId}</strong>
              </div>
              <div>
                <span>Amount</span>
                <strong>{formatPrice(order.total, order.currency)}</strong>
              </div>
              {minutes !== null && (
                <div>
                  <span>Time remaining</span>
                  <strong>{minutes}:{String(seconds).padStart(2, '0')}</strong>
                </div>
              )}
            </div>

            {order.provider === 'test-mode' && (
              <div className="payment-status__testmode">
                <strong>Payment gateway not configured — Test Mode</strong>
                <p>
                  No real payment provider is connected yet. Use the buttons below to simulate a
                  provider response for testing. This panel and the underlying route are disabled
                  automatically once a real gateway is configured or in production.
                </p>
                <div className="payment-status__testbtns">
                  <Button variant="secondary" onClick={() => handleDevSimulate('SUCCESS')}>
                    Simulate Success
                  </Button>
                  <Button variant="ghost" onClick={() => handleDevSimulate('FAILED')}>
                    Simulate Failure
                  </Button>
                </div>
              </div>
            )}

            {order.provider !== 'test-mode' && (
              <p className="payment-status__methods">Supported payment methods depend on your configured provider.</p>
            )}
          </>
        )}

        {error && <p className="payment-status__error">{error}</p>}

        <Link to="/cart" className="payment-status__cancel">Cancel and return to cart</Link>
      </div>
    </section>
  );
}
