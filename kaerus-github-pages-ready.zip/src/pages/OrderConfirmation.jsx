import { useSearchParams, Link } from 'react-router-dom';
import { useOrders } from '../context/OrdersContext';
import PageHeader from '../components/PageHeader';
import Button from '../components/Button';
import { formatPrice } from '../utils/pricing';
import './OrderConfirmation.css';

export default function OrderConfirmation() {
  const [searchParams] = useSearchParams();
  const orderId = searchParams.get('orderId');
  const { getOrder } = useOrders();
  const order = orderId ? getOrder(orderId) : null;

  if (!order) {
    return (
      <>
        <PageHeader eyebrow="Order" title="Order not found" />
        <div className="container order-confirmation__empty">
          <p>We don't have a record of that order on this device. Check My Products or your confirmation email.</p>
          <Button variant="primary" to="/my-products">Go to My Products</Button>
        </div>
      </>
    );
  }

  return (
    <>
      <PageHeader eyebrow="Order confirmation" title={`Order ${order.orderId}`} />
      <section className="order-confirmation">
        <div className="container order-confirmation__card">
          <div className="order-confirmation__row">
            <span>Status</span>
            <strong className={`order-confirmation__status order-confirmation__status--${order.status?.toLowerCase()}`}>
              {order.status}
            </strong>
          </div>
          <div className="order-confirmation__row">
            <span>Email</span>
            <strong>{order.customerEmail}</strong>
          </div>
          <div className="order-confirmation__row">
            <span>Total</span>
            <strong>{formatPrice(order.total, order.currency)}</strong>
          </div>
          {order.transactionId && (
            <div className="order-confirmation__row">
              <span>Transaction reference</span>
              <strong>{order.transactionId}</strong>
            </div>
          )}

          <h2>Items</h2>
          <ul className="order-confirmation__items">
            {order.items.map((item) => (
              <li key={item.id}>
                <span>{item.name}</span>
                <span>{formatPrice(item.price * item.quantity)}</span>
              </li>
            ))}
          </ul>

          <div className="order-confirmation__actions">
            {order.status === 'SUCCESS' ? (
              <Button variant="primary" to="/my-products">View in My Products</Button>
            ) : (
              <Button variant="primary" to={`/payment-status?orderId=${encodeURIComponent(order.orderId)}`}>
                Check Payment Status
              </Button>
            )}
            <Button variant="ghost" to="/shop">Continue shopping</Button>
          </div>
        </div>
      </section>
    </>
  );
}
