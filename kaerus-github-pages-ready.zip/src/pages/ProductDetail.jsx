import { useState } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { getProductById, getRelatedProducts } from '../data/products';
import { getReviewsForProduct } from '../data/reviews';
import ProductVisual from '../components/ProductVisual';
import ProductCard from '../components/ProductCard';
import StarRating from '../components/StarRating';
import Button from '../components/Button';
import Reveal from '../components/Reveal';
import { formatPrice } from '../utils/pricing';
import { useCart } from '../context/CartContext';
import { useCheckout } from '../context/CheckoutContext';
import NotFound from './NotFound';
import './ProductDetail.css';

const TABS = ['Overview', "What's Included", 'Features', 'Requirements', 'File Info', 'How It Works', 'Reviews', 'FAQ'];

export default function ProductDetail() {
  const { productId } = useParams();
  const product = getProductById(productId);
  const navigate = useNavigate();
  const { addItem } = useCart();
  const { setIntentFromBuyNow } = useCheckout();
  const [activeTab, setActiveTab] = useState('Overview');
  const [activeImage, setActiveImage] = useState(0);

  if (!product) return <NotFound />;

  const reviews = getReviewsForProduct(product.id);
  const related = getRelatedProducts(product, 4);

  function handleAddToCart() {
    addItem(product, 1);
  }
  function handleBuyNow() {
    setIntentFromBuyNow(product, 1);
    navigate('/checkout');
  }

  return (
    <>
      <div className="container product-detail__breadcrumb">
        <Link to="/shop">Shop</Link> <span>/</span> <span>{product.category}</span> <span>/</span> <span>{product.name}</span>
      </div>

      <section className="product-detail">
        <div className="container product-detail__top">
          <div className="product-detail__gallery">
            <div className="product-detail__mainimage">
              <ProductVisual coverImage={product.previewImages[activeImage]} label={product.name} variant="hero" />
            </div>
            <div className="product-detail__thumbs">
              {product.previewImages.map((img, i) => (
                <button
                  key={img + i}
                  type="button"
                  className={`product-detail__thumbbtn ${activeImage === i ? 'active' : ''}`}
                  onClick={() => setActiveImage(i)}
                  aria-label={`Preview image ${i + 1}`}
                >
                  <ProductVisual coverImage={img} label={product.name} variant="thumb" />
                </button>
              ))}
            </div>
          </div>

          <div className="product-detail__info">
            <span className="product-detail__category">{product.category}</span>
            <h1>{product.name}</h1>
            <p className="product-detail__tagline">{product.tagline}</p>

            <div className="product-detail__rating">
              <StarRating rating={product.rating} />
              <span>{product.rating}</span>
              <span className="product-detail__reviewcount">({product.reviewCount} reviews)</span>
              <span className="product-detail__sales">· {product.salesCount.toLocaleString()} sold</span>
            </div>

            <div className="product-detail__price">
              <span className="product-detail__pricenow">{formatPrice(product.price)}</span>
              {product.originalPrice && (
                <>
                  <span className="product-detail__priceold">{formatPrice(product.originalPrice)}</span>
                  <span className="product-detail__savings">
                    Save {formatPrice(product.originalPrice - product.price)}
                  </span>
                </>
              )}
            </div>

            <p className="product-detail__desc">{product.shortDescription}</p>

            <div className="product-detail__actions">
              <Button variant="secondary" size="lg" onClick={handleAddToCart}>
                Add to Cart
              </Button>
              <Button variant="primary" size="lg" onClick={handleBuyNow}>
                Buy Now
              </Button>
            </div>

            <div className="product-detail__secure">
              <SecureIcon />
              <span>Secure payment · Instant digital delivery · 14-day refund policy</span>
            </div>

            <dl className="product-detail__meta">
              <div>
                <dt>File type</dt>
                <dd>{product.fileType}</dd>
              </div>
              <div>
                <dt>Size</dt>
                <dd>{product.fileSizeMb} MB</dd>
              </div>
              <div>
                <dt>Version</dt>
                <dd>{product.version}</dd>
              </div>
            </dl>
          </div>
        </div>

        <div className="container product-detail__tabs">
          <div className="product-detail__tabnav" role="tablist">
            {TABS.map((tab) => (
              <button
                key={tab}
                type="button"
                role="tab"
                aria-selected={activeTab === tab}
                className={activeTab === tab ? 'active' : ''}
                onClick={() => setActiveTab(tab)}
              >
                {tab}
              </button>
            ))}
          </div>

          <div className="product-detail__tabpanel" role="tabpanel">
            {activeTab === 'Overview' && (
              <div className="product-detail__prose">
                {product.fullDescription.split('\n\n').map((para, i) => (
                  <p key={i}>{para}</p>
                ))}
              </div>
            )}

            {activeTab === "What's Included" && (
              <ul className="product-detail__filelist">
                {product.whatsIncluded.map((file) => (
                  <li key={file.name}>
                    <FileIcon />
                    <span className="product-detail__filename">{file.name}</span>
                    <span className="product-detail__filemeta">{file.type} · {file.size}</span>
                  </li>
                ))}
              </ul>
            )}

            {activeTab === 'Features' && (
              <ul className="product-detail__checklist">
                {product.features.map((f) => (
                  <li key={f}>
                    <CheckIcon /> {f}
                  </li>
                ))}
              </ul>
            )}

            {activeTab === 'Requirements' && (
              <div className="product-detail__prose">
                <p>{product.requirements}</p>
                <p><strong>Compatibility:</strong> {product.compatibility}</p>
              </div>
            )}

            {activeTab === 'File Info' && (
              <dl className="product-detail__filemetagrid">
                <div><dt>File type</dt><dd>{product.fileType}</dd></div>
                <div><dt>Total size</dt><dd>{product.fileSizeMb} MB</dd></div>
                <div><dt>Number of files</dt><dd>{product.fileCount}</dd></div>
                <div><dt>Version</dt><dd>{product.version}</dd></div>
                <div><dt>Compatibility</dt><dd>{product.compatibility}</dd></div>
              </dl>
            )}

            {activeTab === 'How It Works' && (
              <ol className="product-detail__steps">
                {product.howItWorks.map((step, i) => (
                  <li key={i}>
                    <span className="product-detail__stepnum">{i + 1}</span>
                    <span>{step}</span>
                  </li>
                ))}
              </ol>
            )}

            {activeTab === 'Reviews' && (
              <div className="product-detail__reviews">
                {reviews.length === 0 ? (
                  <p>No reviews yet for this product.</p>
                ) : (
                  reviews.map((review) => (
                    <div key={review.id} className="product-detail__review">
                      <div className="product-detail__reviewhead">
                        <strong>{review.name}</strong>
                        {review.verified && <span className="product-detail__verified">Verified purchase</span>}
                        <span className="product-detail__reviewdate">{review.date}</span>
                      </div>
                      <StarRating rating={review.rating} size={13} />
                      <p>{review.text}</p>
                    </div>
                  ))
                )}
              </div>
            )}

            {activeTab === 'FAQ' && (
              <div className="product-detail__faqlist">
                {product.faq.map((item) => (
                  <details key={item.q}>
                    <summary>{item.q}</summary>
                    <p>{item.a}</p>
                  </details>
                ))}
                <p className="product-detail__refundnote">{product.refundInfo}</p>
              </div>
            )}
          </div>
        </div>

        {related.length > 0 && (
          <div className="container product-detail__related">
            <Reveal>
              <h2>You might also like</h2>
            </Reveal>
            <div className="product-detail__relatedgrid">
              {related.map((p, i) => (
                <Reveal key={p.id} delay={i * 0.05}>
                  <ProductCard product={p} />
                </Reveal>
              ))}
            </div>
          </div>
        )}
      </section>
    </>
  );
}

function SecureIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">
      <path d="M12 2l8 3.5v6c0 5-3.4 8.4-8 10.5-4.6-2.1-8-5.5-8-10.5v-6L12 2z" stroke="currentColor" strokeWidth="1.6" fill="none" strokeLinejoin="round" />
    </svg>
  );
}
function FileIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true">
      <path d="M6 2h9l5 5v15H6V2z" stroke="currentColor" strokeWidth="1.6" fill="none" strokeLinejoin="round" />
      <path d="M15 2v5h5" stroke="currentColor" strokeWidth="1.6" fill="none" strokeLinejoin="round" />
    </svg>
  );
}
function CheckIcon() {
  return (
    <svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true" style={{ flexShrink: 0 }}>
      <path d="M5 12.5l4.5 4.5L19 7" stroke="#5EEAD4" strokeWidth="2" fill="none" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
