// Sample reviews, keyed by product id. Replace with real reviews (or a
// reviews table/API) before production.

export const reviews = {
  'creator-productivity-starter-pack': [
    { id: 'r1', name: 'Marta', rating: 5, date: '2026-08-14', verified: true, text: "I've bought three planning templates before this one and actually used none of them past week two. This one stuck — mostly because it's short enough to open on a Sunday without dreading it." },
    { id: 'r2', name: 'Devon', rating: 4, date: '2026-07-30', verified: true, text: 'Solid system. Docked one star only because I wish the Notion version had a mobile-friendly view by default.' },
    { id: 'r3', name: 'Priya', rating: 5, date: '2026-07-02', verified: true, text: 'The prompt swipe file alone was worth it for me. Simple, no fluff.' },
    { id: 'r4', name: 'Callum', rating: 5, date: '2026-06-18', verified: false, text: 'Recommended by a friend, glad I picked it up. Straightforward and well organized.' },
  ],
  'ultimate-business-launch-kit': [
    { id: 'r1', name: 'Renata', rating: 5, date: '2026-08-20', verified: true, text: 'Used the budget tracker to actually understand my runway for the first time. Everything else in the kit is a bonus at this point.' },
    { id: 'r2', name: 'Tomas', rating: 5, date: '2026-08-01', verified: true, text: 'Sequenced really well — I stopped jumping between five different templates and just followed this one path.' },
    { id: 'r3', name: 'Aisha', rating: 4, date: '2026-07-11', verified: true, text: 'Great value. The pitch outline needed some adapting for my industry but that was expected.' },
    { id: 'r4', name: 'Ben', rating: 5, date: '2026-06-25', verified: true, text: 'Worth more than the asking price honestly.' },
  ],
  'ai-productivity-toolkit': [
    { id: 'r1', name: 'Lucia', rating: 5, date: '2026-08-05', verified: true, text: 'The reasoning notes next to each prompt are the actual value here, not the prompts themselves.' },
    { id: 'r2', name: 'Farid', rating: 4, date: '2026-07-19', verified: true, text: 'Good library, a couple of the prompts overlap a lot with each other.' },
    { id: 'r3', name: 'Noor', rating: 5, date: '2026-07-03', verified: false, text: 'Cleanest prompt pack I have used. Not bloated.' },
  ],
  'premium-website-ui-pack': [
    { id: 'r1', name: 'Ilya', rating: 5, date: '2026-08-22', verified: true, text: 'Handed this straight to my dev and there were basically zero questions during handoff. That never happens.' },
    { id: 'r2', name: 'Grace', rating: 5, date: '2026-08-09', verified: true, text: 'The dark variant alone saved me a week of work.' },
    { id: 'r3', name: 'Samuel', rating: 4, date: '2026-07-14', verified: true, text: 'Very solid kit. Would like a couple more pricing page variants.' },
    { id: 'r4', name: 'Wren', rating: 5, date: '2026-06-30', verified: true, text: 'Finally a UI kit that does not look like every other UI kit.' },
  ],
  'digital-marketing-blueprint': [
    { id: 'r1', name: 'Oscar', rating: 5, date: '2026-08-11', verified: true, text: 'Appreciated that it told me to pick fewer channels, not more. Most guides do the opposite.' },
    { id: 'r2', name: 'Hana', rating: 4, date: '2026-07-22', verified: true, text: 'Solid plan, the measurement dashboard is basic but functional.' },
  ],
  'freelancer-client-kit': [
    { id: 'r1', name: 'Diego', rating: 5, date: '2026-08-17', verified: true, text: 'The proposal template alone has paid for itself twice over in closed projects.' },
    { id: 'r2', name: 'Emeka', rating: 4, date: '2026-07-28', verified: true, text: 'Good starting point for the contract, had my lawyer adjust a couple of clauses as recommended.' },
    { id: 'r3', name: 'Ingrid', rating: 5, date: '2026-07-06', verified: true, text: 'Onboarding form has saved me so many back-and-forth emails.' },
  ],
  'social-growth-templates': [
    { id: 'r1', name: 'Yara', rating: 5, date: '2026-08-13', verified: true, text: 'Organizing by goal instead of just format changed how I actually plan posts.' },
    { id: 'r2', name: 'Matteo', rating: 4, date: '2026-07-25', verified: true, text: 'Great templates, wish there were a couple more for carousels specifically.' },
    { id: 'r3', name: 'Zoe', rating: 5, date: '2026-06-29', verified: false, text: 'Clean, editable, no watermark hunting required.' },
  ],
  'business-finance-dashboard': [
    { id: 'r1', name: 'Karim', rating: 5, date: '2026-08-19', verified: true, text: "I'm not a numbers person and this made my runway click for the first time." },
    { id: 'r2', name: 'Sofia', rating: 5, date: '2026-07-30', verified: true, text: 'No macros, opens cleanly in Google Sheets exactly as promised.' },
    { id: 'r3', name: 'Liam', rating: 4, date: '2026-07-08', verified: true, text: 'Does what it says. Would like a quarterly view in addition to monthly.' },
  ],
};

export function getReviewsForProduct(productId) {
  return reviews[productId] || [];
}
