// Site-wide copy and structured content. Replace the numbers in STATS with
// real figures before production — they are clearly separated here for
// that reason.

export const BRAND = {
  name: 'Kaerus',
  tagline: 'Tools for the work that matters.',
  description:
    'Kaerus is a digital-products studio building templates, guides, and tools for people who ship — creators, founders, and the teams around them.',
};

export const STATS = [
  { value: 10000, suffix: '+', label: 'Downloads', prefix: '' },
  { value: 4.9, suffix: '/5', label: 'Average rating', prefix: '', decimals: 1 },
  { value: 150, suffix: '+', label: 'Digital resources', prefix: '' },
  { value: 24, suffix: '/7', label: 'Instant delivery', prefix: '' },
];

export const TRUST_ITEMS = [
  {
    title: 'Secure payments',
    description: 'Every transaction is verified server-side before an order is ever marked paid.',
    icon: 'shield',
  },
  {
    title: 'Instant delivery',
    description: 'Your files unlock the moment payment is confirmed — no waiting on email.',
    icon: 'bolt',
  },
  {
    title: 'Premium resources',
    description: 'Every product is reviewed for quality before it goes on the shelf.',
    icon: 'star',
  },
  {
    title: 'Real support',
    description: "Questions about a product or an order reach an actual person, not a bot.",
    icon: 'message',
  },
];

export const SITE_FAQ = [
  {
    q: 'How do I receive my product?',
    a: "Right after your payment is verified, you'll land on a success page with a download button, and a copy of your order and download link is available anytime from My Products.",
  },
  {
    q: 'When will I get access?',
    a: 'Immediately after payment is confirmed by the payment provider — typically within seconds.',
  },
  {
    q: 'What file formats are included?',
    a: 'It depends on the product. Every product page lists exact file types, sizes, and what\u2019s included before you buy.',
  },
  {
    q: 'Can I use the product commercially?',
    a: 'Most products include a commercial-use license — check the individual product page for specifics, since terms can vary by item.',
  },
  {
    q: 'What happens if my payment fails?',
    a: "Your order is not marked as paid and you won't be charged for a failed attempt. You can try again from your cart at any time.",
  },
  {
    q: 'Can I get a refund?',
    a: 'Yes — most products are covered by our 14-day refund policy. See our Refund Policy page for full details.',
  },
  {
    q: 'How long do downloads remain available?',
    a: 'Once your order is paid, your download stays accessible in My Products indefinitely, so you can always come back for it.',
  },
  {
    q: 'How do I contact support?',
    a: 'Use the Contact page — we read every message and typically reply within one business day.',
  },
];

export const NAV_LINKS = [
  { label: 'Home', to: '/' },
  { label: 'Shop', to: '/shop' },
  { label: 'Best Sellers', to: '/shop?filter=bestseller' },
  { label: 'About', to: '/about' },
];

export const FOOTER_LINKS = {
  Store: [
    { label: 'Shop', to: '/shop' },
    { label: 'Best Sellers', to: '/shop?filter=bestseller' },
  ],
  Company: [
    { label: 'About', to: '/about' },
    { label: 'FAQ', to: '/faq' },
  ],
};
