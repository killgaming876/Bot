// Centralized product catalog.
// In production, replace this static array with data fetched from your
// database/CMS. Every product keeps the same shape so the rest of the
// app (cards, detail pages, cart, checkout) never needs to change.
//
// IMPORTANT: "isTestProduct: true" marks the one product wired for a full
// end-to-end purchase test. See README "START HERE" for details.

export const CATEGORIES = [
  'Business',
  'AI & Productivity',
  'Website Templates',
  'Social Media',
  'Creator Tools',
  'Education',
  'Finance Templates',
  'Design Resources',
];

export const products = [
  {
    id: 'creator-productivity-starter-pack',
    isTestProduct: true,
    name: 'Creator Productivity Starter Pack',
    category: 'Creator Tools',
    tagline: 'The exact system I use to plan a month of content in one sitting.',
    shortDescription:
      'A lightweight planning system for creators: a content calendar, a weekly checklist, and a bonus swipe file to get unstuck.',
    fullDescription:
      "This is the starter kit I wish I'd had when I started publishing every week. It's not a course, and it's not 40 pages of theory — it's the actual templates I use, stripped of anything that doesn't earn its place. Open it, duplicate the calendar, and plan your next four weeks in under an hour.\n\nBuilt for solo creators and small teams who want a repeatable system rather than a fresh burst of motivation every Monday.",
    price: 19,
    originalPrice: 29,
    discountPercent: 34,
    coverImage: 'gradient-1',
    previewImages: ['gradient-1', 'gradient-1b', 'gradient-1c'],
    fileType: 'PDF + Notion Template',
    fileSizeMb: 8,
    fileCount: 4,
    version: '1.2',
    compatibility: 'Notion, Adobe Acrobat, any PDF reader',
    features: [
      '12-week content calendar (Notion + PDF)',
      'Weekly planning checklist',
      'Idea capture template',
      'Bonus: 30-prompt swipe file for slow weeks',
    ],
    whatsIncluded: [
      { name: 'Content Calendar.pdf', type: 'PDF', size: '2.1 MB' },
      { name: 'Weekly Planner Template.pdf', type: 'PDF', size: '1.4 MB' },
      { name: 'Idea Checklist.pdf', type: 'PDF', size: '0.8 MB' },
      { name: 'Bonus Prompt Swipe File.pdf', type: 'PDF', size: '3.2 MB' },
    ],
    tags: ['planning', 'notion', 'beginner-friendly', 'bestseller'],
    badges: ['Bestseller'],
    rating: 4.8,
    reviewCount: 214,
    salesCount: 3120,
    faq: [
      {
        q: 'Do I need Notion to use this?',
        a: 'No. Everything is included as PDF as well, so you can use it with any planner or print it out. The Notion version is a bonus for people who already work there.',
      },
      {
        q: 'Is this good for someone just starting out?',
        a: 'Yes — it was designed specifically to remove decision fatigue for people posting consistently for the first time.',
      },
    ],
    refundInfo:
      'Covered by our standard 14-day refund policy if the product genuinely does not fit your workflow.',
    howItWorks: [
      'Download your files instantly after checkout.',
      'Duplicate the Notion calendar into your own workspace, or print the PDF planner.',
      'Fill in your next 4 weeks using the prompt swipe file if you get stuck.',
    ],
    requirements: 'No special software required. Notion account optional and free.',
  },
  {
    id: 'ultimate-business-launch-kit',
    name: 'Ultimate Business Launch Kit',
    category: 'Business',
    tagline: 'Everything to go from idea to first customer, organized in one place.',
    shortDescription:
      'A complete kit of business planning documents: a lean business plan, pitch outline, budget tracker, and legal checklist.',
    fullDescription:
      "Most 'business kits' are recycled templates with no structure. This one is sequenced: you move through validation, planning, budgeting, and launch in an order that actually makes sense. Built from patterns we've seen work across dozens of first-time founders.\n\nWhether you're launching a service, a product, or a side project you want to take seriously, this kit gives you the paperwork so you can focus on the actual business.",
    price: 39,
    originalPrice: 59,
    discountPercent: 34,
    coverImage: 'gradient-2',
    previewImages: ['gradient-2', 'gradient-2b', 'gradient-2c'],
    fileType: 'PDF + Excel',
    fileSizeMb: 14,
    fileCount: 6,
    version: '2.0',
    compatibility: 'Microsoft Excel, Google Sheets, Adobe Acrobat',
    features: [
      'Lean business plan template',
      'Startup budget & runway tracker (Excel)',
      'Investor-ready pitch outline',
      'Legal & compliance pre-launch checklist',
      'Break-even calculator',
    ],
    whatsIncluded: [
      { name: 'Lean Business Plan.pdf', type: 'PDF', size: '2.4 MB' },
      { name: 'Budget & Runway Tracker.xlsx', type: 'Excel', size: '1.1 MB' },
      { name: 'Pitch Outline.pdf', type: 'PDF', size: '1.8 MB' },
      { name: 'Legal Checklist.pdf', type: 'PDF', size: '0.9 MB' },
      { name: 'Break-Even Calculator.xlsx', type: 'Excel', size: '0.6 MB' },
      { name: 'Launch Timeline.pdf', type: 'PDF', size: '1.2 MB' },
    ],
    tags: ['startup', 'planning', 'finance', 'bestseller'],
    badges: ['Bestseller', 'Popular'],
    rating: 4.9,
    reviewCount: 341,
    salesCount: 5210,
    faq: [
      {
        q: 'Is this suitable outside the US?',
        a: 'Yes, the templates are jurisdiction-agnostic. The legal checklist flags where you should confirm local requirements.',
      },
      {
        q: 'Can I use this to raise funding?',
        a: 'The pitch outline is designed to get your thinking investor-ready, but you should adapt it to your specific round and audience.',
      },
    ],
    refundInfo: 'Covered by our standard 14-day refund policy.',
    howItWorks: [
      'Download all files immediately after purchase.',
      'Work through the plan in sequence: validation, plan, budget, pitch, launch.',
      'Customize each template directly in Excel/Google Sheets or your PDF editor.',
    ],
    requirements: 'Excel or Google Sheets recommended for the budget tools.',
  },
  {
    id: 'ai-productivity-toolkit',
    name: 'AI Productivity Toolkit',
    category: 'AI & Productivity',
    tagline: 'A tested prompt library for the work you actually do every week.',
    shortDescription:
      'Over 120 categorized prompts for writing, research, planning, and analysis, tuned for real workflows rather than novelty demos.',
    fullDescription:
      "Most prompt packs are a wall of generic one-liners. This one is organized by job-to-be-done — weekly reporting, first drafts, meeting follow-ups, research summaries — and each prompt includes the reasoning behind why it's structured that way, so you can adapt it instead of just copying it.\n\nWorks with any major assistant; nothing here is locked to one provider.",
    price: 24,
    originalPrice: null,
    discountPercent: 0,
    coverImage: 'gradient-3',
    previewImages: ['gradient-3', 'gradient-3b', 'gradient-3c'],
    fileType: 'PDF + Notion',
    fileSizeMb: 6,
    fileCount: 3,
    version: '1.4',
    compatibility: 'Works with any AI assistant; Notion optional',
    features: [
      '120+ categorized prompts',
      'Reasoning notes for adapting each prompt',
      'Notion database version with tags and search',
      'Quarterly update policy for new prompts',
    ],
    whatsIncluded: [
      { name: 'Prompt Library.pdf', type: 'PDF', size: '3.4 MB' },
      { name: 'Notion Prompt Database', type: 'Notion Template', size: '1.2 MB' },
      { name: 'Quick Reference Card.pdf', type: 'PDF', size: '0.5 MB' },
    ],
    tags: ['ai', 'prompts', 'productivity', 'new'],
    badges: ['New'],
    rating: 4.7,
    reviewCount: 88,
    salesCount: 960,
    faq: [
      {
        q: 'Does this work with any specific AI tool?',
        a: 'No — every prompt is written to be tool-agnostic and works well with any capable assistant.',
      },
      {
        q: 'Will I get future updates?',
        a: 'Yes, quarterly additions are included at no extra cost for the lifetime of this version.',
      },
    ],
    refundInfo: 'Covered by our standard 14-day refund policy.',
    howItWorks: [
      'Download the PDF and/or duplicate the Notion database.',
      'Find the category matching your task.',
      'Copy the prompt and adjust the bracketed placeholders for your context.',
    ],
    requirements: 'Any AI assistant. Notion optional and free.',
  },
  {
    id: 'premium-website-ui-pack',
    name: 'Premium Website UI Pack',
    category: 'Website Templates',
    tagline: 'A design system for marketing sites that doesn\u2019t look like a template.',
    shortDescription:
      'A Figma UI kit with 60+ components and 8 full page templates for SaaS and product marketing sites.',
    fullDescription:
      "Built for teams who are tired of every landing page looking like every other landing page. This kit gives you a real design system — type scale, spacing tokens, component variants — plus 8 complete page templates you can restyle in an afternoon rather than rebuild from scratch.\n\nExports cleanly to code: layouts use standard auto-layout and consistent naming so handoff to engineering doesn't turn into a translation exercise.",
    price: 49,
    originalPrice: 79,
    discountPercent: 38,
    coverImage: 'gradient-4',
    previewImages: ['gradient-4', 'gradient-4b', 'gradient-4c'],
    fileType: 'Figma',
    fileSizeMb: 42,
    fileCount: 1,
    version: '3.1',
    compatibility: 'Figma (free or paid account)',
    features: [
      '60+ reusable components',
      '8 complete page templates',
      'Full type scale and spacing tokens',
      'Light and dark variants',
      'Auto-layout throughout for fast edits',
    ],
    whatsIncluded: [
      { name: 'Kaerus UI Kit.fig', type: 'Figma File', size: '42 MB' },
    ],
    tags: ['figma', 'design system', 'saas', 'bestseller'],
    badges: ['Bestseller'],
    rating: 4.9,
    reviewCount: 176,
    salesCount: 2430,
    faq: [
      {
        q: 'Do I need a paid Figma plan?',
        a: 'No, the free tier is enough to duplicate and edit this file.',
      },
      {
        q: 'Can I use this for client projects?',
        a: 'Yes, the commercial license covers client work. See the license file included in the download.',
      },
    ],
    refundInfo: 'Covered by our standard 14-day refund policy.',
    howItWorks: [
      'Download and open the .fig file in Figma.',
      'Duplicate to your own workspace.',
      'Swap in your brand colors and content using the token styles provided.',
    ],
    requirements: 'A free Figma account.',
  },
  {
    id: 'digital-marketing-blueprint',
    name: 'Digital Marketing Blueprint',
    category: 'Business',
    tagline: 'A 90-day plan for growing an audience without guesswork.',
    shortDescription:
      'A structured 90-day marketing plan covering channel selection, content cadence, and a simple measurement framework.',
    fullDescription:
      "Most marketing advice is either too abstract to act on or too tactical to last. This blueprint sits in between: a 90-day plan broken into weekly actions, with a lightweight measurement framework so you know what's actually working by week 6, not week 52.",
    price: 29,
    originalPrice: 45,
    discountPercent: 36,
    coverImage: 'gradient-5',
    previewImages: ['gradient-5', 'gradient-5b', 'gradient-5c'],
    fileType: 'PDF',
    fileSizeMb: 11,
    fileCount: 2,
    version: '1.1',
    compatibility: 'Any PDF reader',
    features: [
      '90-day week-by-week action plan',
      'Channel selection framework',
      'Simple measurement dashboard template',
      'Worked example from a real launch',
    ],
    whatsIncluded: [
      { name: '90-Day Blueprint.pdf', type: 'PDF', size: '8.2 MB' },
      { name: 'Measurement Dashboard.pdf', type: 'PDF', size: '2.8 MB' },
    ],
    tags: ['marketing', 'growth', 'planning'],
    badges: [],
    rating: 4.6,
    reviewCount: 122,
    salesCount: 1870,
    faq: [
      {
        q: 'Is this for B2B or B2C?',
        a: 'The framework applies to both; the worked example is B2C but the channel-selection logic transfers directly.',
      },
    ],
    refundInfo: 'Covered by our standard 14-day refund policy.',
    howItWorks: [
      'Download instantly after checkout.',
      'Work through the channel-selection framework for your specific audience.',
      'Follow the week-by-week plan and track using the dashboard template.',
    ],
    requirements: 'No special software required.',
  },
  {
    id: 'freelancer-client-kit',
    name: 'Freelancer Client Kit',
    category: 'Business',
    tagline: 'Proposals, contracts, and onboarding docs that make you look established.',
    shortDescription:
      'A complete set of client-facing documents: proposal template, contract template, onboarding form, and offboarding checklist.',
    fullDescription:
      "The paperwork gap is what makes freelancers look new even when they're not. This kit closes it: a proposal template that's actually persuasive, a plain-language contract template, an onboarding form that gets you the information you need up front, and an offboarding checklist so projects end cleanly.\n\nNote: contract template is a starting point, not legal advice — see the disclaimer included in the download.",
    price: 22,
    originalPrice: 34,
    discountPercent: 35,
    coverImage: 'gradient-6',
    previewImages: ['gradient-6', 'gradient-6b', 'gradient-6c'],
    fileType: 'Word + PDF',
    fileSizeMb: 5,
    fileCount: 5,
    version: '1.3',
    compatibility: 'Microsoft Word, Google Docs, Adobe Acrobat',
    features: [
      'Client proposal template',
      'Plain-language service contract template',
      'Client onboarding form',
      'Project offboarding checklist',
      'Late-payment follow-up email scripts',
    ],
    whatsIncluded: [
      { name: 'Proposal Template.docx', type: 'Word', size: '0.8 MB' },
      { name: 'Service Contract Template.docx', type: 'Word', size: '0.6 MB' },
      { name: 'Onboarding Form.pdf', type: 'PDF', size: '0.4 MB' },
      { name: 'Offboarding Checklist.pdf', type: 'PDF', size: '0.3 MB' },
      { name: 'Follow-Up Email Scripts.pdf', type: 'PDF', size: '0.5 MB' },
    ],
    tags: ['freelance', 'contracts', 'clients'],
    badges: ['Popular'],
    rating: 4.7,
    reviewCount: 156,
    salesCount: 2010,
    faq: [
      {
        q: 'Is the contract legally binding?',
        a: 'It is a solid starting template, but we recommend having a local lawyer review it before relying on it for high-value engagements.',
      },
    ],
    refundInfo: 'Covered by our standard 14-day refund policy.',
    howItWorks: [
      'Download instantly after checkout.',
      'Customize the proposal and contract with your business details.',
      'Send the onboarding form to new clients before kickoff.',
    ],
    requirements: 'Microsoft Word or Google Docs.',
  },
  {
    id: 'social-growth-templates',
    name: 'Social Media Growth Templates',
    category: 'Social Media',
    tagline: 'Editable post templates built around what actually gets saved and shared.',
    shortDescription:
      'A set of 40 editable carousel and post templates for Instagram and LinkedIn, organized by content goal.',
    fullDescription:
      "Templates organized by outcome, not just format: templates for teaching a concept, templates for sharing a result, templates for starting a discussion. Each one comes with a short note on why the layout works, so you're not just filling in boxes blindly.",
    price: 27,
    originalPrice: 40,
    discountPercent: 33,
    coverImage: 'gradient-7',
    previewImages: ['gradient-7', 'gradient-7b', 'gradient-7c'],
    fileType: 'Canva + Figma',
    fileSizeMb: 60,
    fileCount: 2,
    version: '2.2',
    compatibility: 'Canva (free), Figma (free)',
    features: [
      '40 editable templates',
      'Organized by content goal, not just platform',
      'Instagram and LinkedIn dimensions included',
      'Brand kit setup guide',
    ],
    whatsIncluded: [
      { name: 'Canva Template Pack (link file)', type: 'Canva', size: '—' },
      { name: 'Figma Source File.fig', type: 'Figma', size: '60 MB' },
    ],
    tags: ['social media', 'design', 'templates'],
    badges: ['Popular'],
    rating: 4.6,
    reviewCount: 203,
    salesCount: 2890,
    faq: [
      {
        q: 'Do I need Canva Pro?',
        a: 'No, everything works on the free Canva plan.',
      },
    ],
    refundInfo: 'Covered by our standard 14-day refund policy.',
    howItWorks: [
      'Open the included Canva link and click "Use template."',
      'Swap in your brand colors and fonts.',
      'Export directly from Canva or edit further in Figma.',
    ],
    requirements: 'Free Canva or Figma account.',
  },
  {
    id: 'business-finance-dashboard',
    name: 'Business Finance Dashboard',
    category: 'Finance Templates',
    tagline: 'See your runway, margins, and cash flow without hiring a bookkeeper.',
    shortDescription:
      'An Excel/Google Sheets dashboard that turns basic income and expense entries into runway, margin, and cash-flow charts automatically.',
    fullDescription:
      "Built for founders who want visibility without complexity. Enter your income and expenses in the simple input tab, and the dashboard automatically builds your runway projection, margin trends, and monthly cash-flow chart. No macros, no plugins, nothing that breaks when you open it in Google Sheets.",
    price: 34,
    originalPrice: 52,
    discountPercent: 35,
    coverImage: 'gradient-8',
    previewImages: ['gradient-8', 'gradient-8b', 'gradient-8c'],
    fileType: 'Excel + Google Sheets',
    fileSizeMb: 3,
    fileCount: 2,
    version: '1.5',
    compatibility: 'Microsoft Excel, Google Sheets',
    features: [
      'Automatic runway projection',
      'Margin trend chart',
      'Monthly cash-flow visualization',
      'No macros or add-ons required',
    ],
    whatsIncluded: [
      { name: 'Finance Dashboard.xlsx', type: 'Excel', size: '1.8 MB' },
      { name: 'Finance Dashboard (Google Sheets copy link).pdf', type: 'PDF', size: '0.2 MB' },
    ],
    tags: ['finance', 'dashboard', 'spreadsheet'],
    badges: [],
    rating: 4.8,
    reviewCount: 94,
    salesCount: 1340,
    faq: [
      {
        q: 'Do I need accounting knowledge to use this?',
        a: 'No — you only need to enter income and expense line items. The dashboard tab handles the rest.',
      },
    ],
    refundInfo: 'Covered by our standard 14-day refund policy.',
    howItWorks: [
      'Download instantly after checkout.',
      'Open in Excel or import into Google Sheets.',
      'Enter your monthly income and expenses in the Input tab.',
    ],
    requirements: 'Microsoft Excel or a free Google account.',
  },
];

export function getProductById(id) {
  return products.find((p) => p.id === id);
}

export function getRelatedProducts(product, limit = 4) {
  return products
    .filter((p) => p.id !== product.id && p.category === product.category)
    .slice(0, limit)
    .concat(
      products.filter((p) => p.id !== product.id && p.category !== product.category)
    )
    .slice(0, limit);
}

export function searchProducts(query) {
  const q = query.trim().toLowerCase();
  if (!q) return products;
  return products.filter((p) => {
    return (
      p.name.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q) ||
      p.shortDescription.toLowerCase().includes(q) ||
      p.tags.some((t) => t.toLowerCase().includes(q))
    );
  });
}
