// Thin wrapper around localStorage with JSON handling and safe fallbacks
// (private browsing / storage-disabled environments won't crash the app).

const memoryFallback = new Map();

function isStorageAvailable() {
  try {
    const testKey = '__kaerus_test__';
    window.localStorage.setItem(testKey, '1');
    window.localStorage.removeItem(testKey);
    return true;
  } catch {
    return false;
  }
}

const storageOk = typeof window !== 'undefined' && isStorageAvailable();

export function readStorage(key, fallback = null) {
  try {
    if (storageOk) {
      const raw = window.localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    }
    return memoryFallback.has(key) ? memoryFallback.get(key) : fallback;
  } catch {
    return fallback;
  }
}

export function writeStorage(key, value) {
  try {
    if (storageOk) {
      window.localStorage.setItem(key, JSON.stringify(value));
    } else {
      memoryFallback.set(key, value);
    }
  } catch {
    memoryFallback.set(key, value);
  }
}

export function removeStorage(key) {
  try {
    if (storageOk) {
      window.localStorage.removeItem(key);
    } else {
      memoryFallback.delete(key);
    }
  } catch {
    memoryFallback.delete(key);
  }
}
