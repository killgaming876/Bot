// Centralized pricing math so cart, checkout, and order summaries never
// drift out of sync with each other.

export function formatPrice(amount, currency = 'USD') {
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency,
    minimumFractionDigits: amount % 1 === 0 ? 0 : 2,
    maximumFractionDigits: 2,
  }).format(amount);
}

export function lineItemTotal(item) {
  return item.price * item.quantity;
}

export function lineItemOriginalTotal(item) {
  return (item.originalPrice ?? item.price) * item.quantity;
}

export function calculateCartTotals(items) {
  const subtotal = items.reduce((sum, item) => sum + lineItemOriginalTotal(item), 0);
  const total = items.reduce((sum, item) => sum + lineItemTotal(item), 0);
  const discount = Math.max(0, subtotal - total);
  return {
    subtotal: round2(subtotal),
    discount: round2(discount),
    total: round2(total),
    itemCount: items.reduce((sum, item) => sum + item.quantity, 0),
  };
}

function round2(n) {
  return Math.round(n * 100) / 100;
}
