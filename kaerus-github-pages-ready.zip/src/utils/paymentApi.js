// Thin client for the payment API routes under /api/payment/*.
// The frontend never decides payment outcomes itself — every call here
// hits the backend, and the backend is the only thing allowed to say an
// order succeeded. See /api/payment/_lib/provider.js for the abstraction.

const BASE = '/api/payment';

async function request(path, options = {}) {
  const res = await fetch(`${BASE}${path}`, {
    method: options.method || 'GET',
    headers: { 'Content-Type': 'application/json' },
    body: options.body ? JSON.stringify(options.body) : undefined,
  });

  let data;
  try {
    data = await res.json();
  } catch {
    data = null;
  }

  if (!res.ok) {
    const message = data?.error || 'Something went wrong talking to the payment service.';
    throw new PaymentApiError(message, res.status, data);
  }

  return data;
}

export class PaymentApiError extends Error {
  constructor(message, status, data) {
    super(message);
    this.name = 'PaymentApiError';
    this.status = status;
    this.data = data;
  }
}

export function createPayment({ items, customerEmail, customerName }) {
  return request('/create-payment', {
    method: 'POST',
    body: { items, customerEmail, customerName },
  });
}

export function getPaymentStatus(orderId) {
  return request(`/status?orderId=${encodeURIComponent(orderId)}`);
}

export function getDownload(orderId, productId) {
  return request(`/download?orderId=${encodeURIComponent(orderId)}&productId=${encodeURIComponent(productId)}`);
}
