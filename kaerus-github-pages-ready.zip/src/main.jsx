import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App.jsx';
import { CartProvider } from './context/CartContext.jsx';
import { CheckoutProvider } from './context/CheckoutContext.jsx';
import { OrdersProvider } from './context/OrdersContext.jsx';
import './styles/global.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter basename="/Bot">
      <CartProvider>
        <CheckoutProvider>
          <OrdersProvider>
            <App />
          </OrdersProvider>
        </CheckoutProvider>
      </CartProvider>
    </BrowserRouter>
  </React.StrictMode>
);
