# Kaerus — Digital Products Store

A premium digital-products storefront: React + Vite frontend, Vercel serverless
API routes for payments, cart/checkout flow, and a safe payment architecture
that never fakes a successful payment.

## START HERE — before accepting real payments

1. This project ships in **Test Mode** — no real payment gateway is connected.
   You'll see "Payment gateway not configured — Test Mode" on the payment
   status page, with buttons to simulate success/failure for testing.
2. To go live, pick **Razorpay** or **Cashfree**, get your API keys, and:
   - Set `PAYMENT_PROVIDER` in your environment (`razorpay` or `cashfree`).
   - Fill in that provider's key/secret env vars (see `.env.example`).
   - Implement the two `TODO`s in `api/payment/_lib/provider.js`
     (`createProviderPayment` and `verifyProviderWebhook`) using that
     provider's SDK/docs.
   - Add your webhook URL (`https://yourdomain.com/api/payment/webhook`) in
     the provider's dashboard.
3. Replace the in-memory order store (`api/_lib/orderStore.js`) with a real
   database — it currently resets on every deploy/cold start.
4. Replace the mock download reference in `api/payment/download.js` with
   real signed/temporary URLs from your file storage.

Until steps 2–4 are done, no request — refresh, URL edit, button click, or
localStorage tampering — can mark an order as paid. Only a verified webhook
from a real, configured provider can do that.

## Install & run locally

```
npm install
npm run dev
```

## Build

```
npm run build
```

## Deploy to Vercel

Push to GitHub, import the repo in Vercel, and add the environment variables
from `.env.example` in your Vercel project settings. `vercel.json` is already
configured for the Vite build output and API routes.

## Project structure

```
src/        Frontend (pages, components, context, data, utils)
api/        Serverless API routes (payment lifecycle)
public/     Static assets
```
